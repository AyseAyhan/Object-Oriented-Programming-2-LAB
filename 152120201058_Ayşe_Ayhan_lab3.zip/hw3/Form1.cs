﻿using System;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testScript;

namespace hw3
{
    /* 152120201058_Ayşe_Ayhan_hw3 */
    public partial class Form1 : Form
    {
       private testClass test=new testClass();   
        string stdNumber="";
        string inputText="";
        string algorithm = "";   //"Caesar"-"Vigenere"
        string enDecSelect = "";  //"encrypt"-"decrypt"
        string outPutText = "";
        string encryptedTextwithCaesar = "";
        string encryptedTextwithVigenere = "";
        string decryptedTextwithCaesar = "";
        string decryptedTextwithVigenere = "";
        int skor = 0;

        public Form1()
        {
            InitializeComponent();
        }

        //Caesar şifreleme algoritması
        public static string CaesarCipher(string text, int key)
        {         
            string encrypted_text = "";

           //girilen metindeki her karakteri öteleyerek bir şifre oluşturur
            foreach (char c in text)
            {
                // karakterin ascii değerini alır
                int ascii_value = (int)c;
              //karakter harf değilse değişiklik yapmaz
                if (ascii_value < 65 || (ascii_value > 90 && ascii_value < 97) || ascii_value > 122)
                {
                    encrypted_text += c;
                }
                else
                {
                    //ascii değerine key value'yu(yani 7) ekleyerek caesar şifreleme yapar
                    int new_ascii_value = (ascii_value + key - 65) % 26 + 65;                
                    char new_char = (char)new_ascii_value;
                    encrypted_text += new_char;
                }
            }
            // fonksiyon, caesar şifresini döndürür
            return encrypted_text;
        }
        
        // caesar şifresini çözen-deşifre eden algoritma
        public static string CaesarDecipher(string encrypted_text, int key)
        {          
            string decrypted_text = "";
 
            //şifrelenmiş metnin karakterlerini öteler
            foreach (char c in encrypted_text)
            {              
                int ascii_value = (int)c;

                //karakter harf değilse değişim yapmaz
                if (ascii_value < 65 || (ascii_value > 90 && ascii_value < 97) || ascii_value > 122)
                {
                    decrypted_text += c;
                }
                else
                {
                    // şifreyi dönüştürmek için ascii değerinden key value'yu çıkarır(7)                   
                    int new_ascii_value = (ascii_value - key - 65 + 26) % 26 + 65;
                    char new_char = (char)new_ascii_value;
                    // deşifrelenmiş texte yeni karakteri ekler
                    decrypted_text += new_char;
                }
            }
           
            //deşifrelenmiş metni döndürür
            return decrypted_text;
        }

        public static string VigenereEncrypt(string correctText, string key)
        {
            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            int keyIndex = 0;
            string cipherTxt = "";

            correctText = correctText.ToUpper();
            key = key.ToUpper();

            for (int i = 0; i < correctText.Length; i++)
            {
                if (!Char.IsLetter(correctText[i]))
                {
                    // harf olmayan karakterleri görmezden gelir
                    cipherTxt += correctText[i];
                    continue;
                }
                char k = key[keyIndex];
                if (!Char.IsLetter(k))
                {
                    MessageBox.Show("Geçersiz: Harf olmayan karakter bulundu!");
                    return "";
                }

                int keyLetterIndex = alphabet.IndexOf(key[keyIndex]);
                int correctLetterIndex = alphabet.IndexOf(correctText[i]);
                int cipherLetterIndex = (keyLetterIndex + correctLetterIndex) % alphabet.Length;

                char cipherLetter = alphabet[cipherLetterIndex];
                cipherTxt += cipherLetter;

                keyIndex++;
                if (keyIndex == key.Length)
                {
                    keyIndex = 0;
                }
            }

            return cipherTxt;
        }


        public static string VigenereDecrypt(string cipherTxt, string key)
        {
            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            int keyIndex = 0;
            string correctText = "";
            cipherTxt = cipherTxt.ToUpper();
            key = key.ToUpper();

            for (int i = 0; i < cipherTxt.Length; i++)
            {
                char c = cipherTxt[i];
                if (!Char.IsLetter(c))
                {
                    // harf olmayanları göz ardı eder
                    correctText += c;
                    continue;
                }

                char k = key[keyIndex];
                if (!Char.IsLetter(k))
                {
                    MessageBox.Show("Invalid key: non-letter character found");
                }

                // karakterleri büyük harfe çevirir
                c = Char.ToUpper(c);
                k = Char.ToUpper(k);

                int keyLetterIndex = alphabet.IndexOf(k);
                int cipherLetterIndex = alphabet.IndexOf(c);

                if (keyLetterIndex < 0 || cipherLetterIndex < 0)
                {
                    MessageBox.Show("Invalid character: character not found in alphabet");
                }

                int plainLetterIndex = (cipherLetterIndex - keyLetterIndex + alphabet.Length) % alphabet.Length;

                char plainLetter = alphabet[plainLetterIndex];

                if (Char.IsLower(cipherTxt[i]))
                {
                    plainLetter = Char.ToLower(plainLetter);
                }

                correctText += plainLetter;

                keyIndex++;
                if (keyIndex == key.Length)
                {
                    keyIndex = 0;
                }
            }
            return correctText;
        }


        private void text_num_TextChanged(object sender, EventArgs e)
        {
            bool isValid=int.TryParse(text_num.Text, out int value);
            if(text_num.Text.Length!=8||!isValid)
            {             
                text_num.BackColor = Color.Red;
                button1.Enabled = false;
            }
            else {
                text_num.BackColor = Color.White;
                stdNumber = text_num.Text;
                button1.Enabled = true; }
        }

        private void text_metin_TextChanged(object sender, EventArgs e)
        {
            bool isValid = int.TryParse(text_num.Text, out int value);  //numara texti değiştirilmeye de bilir, yine de kontrol edilmesi için metin değiştiğinde bu kodu ekledim
            if (text_num.Text.Length != 8 || !isValid)
            {
                text_num.BackColor = Color.Red;
                button1.Enabled = false;
            }
            else
            {
                text_num.BackColor = Color.White;
                stdNumber = text_num.Text;
                button1.Enabled = true;
            }
            if (text_num.BackColor != Color.White) 
            {
                MessageBox.Show("Numara 8 haneli olmalıdır ve yalnızca rakamlardan oluşmalıdır!");
            }

            if (text_metin.Text.Length==0||text_metin.Text==" ") 
            {
                text_metin.BackColor = Color.Red;
                button1.Enabled = false;
            }
            else          
            {
                text_metin.BackColor = Color.White;
                button1.Enabled = true;
                inputText = text_metin.Text;
                encryptedTextwithCaesar = CaesarCipher(inputText,7);
                decryptedTextwithCaesar=CaesarDecipher(inputText,7);
                encryptedTextwithVigenere = VigenereEncrypt(inputText, "esoguce");
                decryptedTextwithVigenere = VigenereDecrypt(inputText, "esoguce");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
            text_num.BackColor = Color.White; 
        }

        //radiobutton+ fonksiyon çağrıları, skor hesabı partı
        private void button1_Click(object sender, EventArgs e)
        {         
            if (text_metin.BackColor != Color.White)
            {
                MessageBox.Show("Metin kutusu boş bırakılamaz!");
            }
            else
            {
                if(rb_caes.Checked)
                {
                    algorithm = "Caesar";
                    if (rb_sifre.Checked)
                    {
                        enDecSelect = "encrypt";
                        outPutText =CaesarCipher(text_metin.Text, 7);
                        label_sonuc.Text = outPutText; 
                    }
                    else if (rb_desif.Checked)
                    {
                        enDecSelect = "decrypt";
                        outPutText =CaesarDecipher(text_metin.Text, 7);
                        label_sonuc.Text = outPutText;                     
                    }
                    else
                    {
                        MessageBox.Show("Şifreleme ya da Deşifrelemeden birini seçiniz!");
                    }
                }
                else if(rb_vig.Checked)
                {
                    algorithm = "Vigenere";
                    if (rb_sifre.Checked)
                    {
                        enDecSelect = "encrypt";
                        outPutText =VigenereEncrypt(text_metin.Text, "esoguce");
                        label_sonuc.Text = outPutText;
                    }
                    else if (rb_desif.Checked)
                    {
                        enDecSelect = "decrypt";
                        outPutText = VigenereDecrypt(text_metin.Text, "esoguce");
                        label_sonuc.Text = outPutText;
                    }
                    else
                    {
                        MessageBox.Show("Şifreleme ya da Deşifrelemeden birini seçiniz!");
                    }
                }
                else
                {
                    MessageBox.Show("Bir algoritma seçiniz!");
                }

                string directory=Directory.GetCurrentDirectory();
                // dosya adını tanımlama
                string fileName = Path.Combine(directory, $"{stdNumber}.csv");
                //string fileName = "username.csv";
                //tring fileName = $"{stdNumber}.csv";

                try
                {
                    //dosya mevcut değilse oluşturup içine yaz+kaydet
                    if (!File.Exists(fileName))
                    {
                        StreamWriter wr = new StreamWriter(fileName);
                        wr.WriteLine(outPutText + (Environment.NewLine)); 
                        wr.Close();
                        //obje üzerinden testDuncApp3 fonksiyonunun çağrısı ve skorun hesaplanması
                        skor = test.testFuncApp3(stdNumber, inputText, algorithm, enDecSelect, outPutText, encryptedTextwithCaesar, encryptedTextwithVigenere, decryptedTextwithCaesar, decryptedTextwithVigenere);
                        label_skor.Text = "Skor: " + skor.ToString();
                        MessageBox.Show("Dosya kaydedildi!");
                    }
                    else
                    {
                        //dosya mevcutsa içine yaz +kaydet   //üzerine yazma işlemi yapar
                       File.WriteAllText(fileName, outPutText+(Environment.NewLine));  //üzerine yazması için
                       // File.AppendAllText(fileName, outPutText+(Environment.NewLine));  //üzerine eklemesi için
                        MessageBox.Show("Veriler kaydedildi!");
                        //obje üzerinden testDuncApp3 fonksiyonunun çağrısı ve skorun hesaplanması
                        skor = test.testFuncApp3(stdNumber, inputText, algorithm, enDecSelect, outPutText, encryptedTextwithCaesar, encryptedTextwithVigenere, decryptedTextwithCaesar, decryptedTextwithVigenere);
                        label_skor.Text = "Skor: " + skor.ToString();
                    }
                }
                catch (Exception)
                {
                    return;
                }
                //skor = test.testFuncApp3(stdNumber, inputText, algorithm, enDecSelect, outPutText, encryptedTextwithCaesar, encryptedTextwithVigenere, decryptedTextwithCaesar, decryptedTextwithVigenere);
               // label_skor.Text = skor.ToString(); 
            }
        }
    }
}
