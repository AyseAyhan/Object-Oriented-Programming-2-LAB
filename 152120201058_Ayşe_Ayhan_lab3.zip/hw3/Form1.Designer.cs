﻿namespace hw3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_no = new System.Windows.Forms.Label();
            this.text_num = new System.Windows.Forms.TextBox();
            this.label_skor = new System.Windows.Forms.Label();
            this.label_passw = new System.Windows.Forms.Label();
            this.text_metin = new System.Windows.Forms.TextBox();
            this.gb_alg = new System.Windows.Forms.GroupBox();
            this.rb_caes = new System.Windows.Forms.RadioButton();
            this.rb_vig = new System.Windows.Forms.RadioButton();
            this.gb_passw = new System.Windows.Forms.GroupBox();
            this.rb_sifre = new System.Windows.Forms.RadioButton();
            this.rb_desif = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.label_sonuc = new System.Windows.Forms.Label();
            this.gb_alg.SuspendLayout();
            this.gb_passw.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_no
            // 
            this.label_no.Location = new System.Drawing.Point(65, 47);
            this.label_no.Name = "label_no";
            this.label_no.Size = new System.Drawing.Size(118, 27);
            this.label_no.TabIndex = 0;
            this.label_no.Text = "Öğrenci Numarası:";
            // 
            // text_num
            // 
            this.text_num.Location = new System.Drawing.Point(173, 47);
            this.text_num.Name = "text_num";
            this.text_num.Size = new System.Drawing.Size(129, 20);
            this.text_num.TabIndex = 1;
            this.text_num.Text = "20201058";
            this.text_num.TextChanged += new System.EventHandler(this.text_num_TextChanged);
            // 
            // label_skor
            // 
            this.label_skor.BackColor = System.Drawing.SystemColors.Control;
            this.label_skor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_skor.Location = new System.Drawing.Point(609, 9);
            this.label_skor.Name = "label_skor";
            this.label_skor.Size = new System.Drawing.Size(162, 35);
            this.label_skor.TabIndex = 2;
            this.label_skor.Text = "Skor:";
            // 
            // label_passw
            // 
            this.label_passw.Location = new System.Drawing.Point(65, 93);
            this.label_passw.Name = "label_passw";
            this.label_passw.Size = new System.Drawing.Size(369, 23);
            this.label_passw.TabIndex = 3;
            this.label_passw.Text = "Şifrelenecek/Şifresi çözülecek metin:";
            // 
            // text_metin
            // 
            this.text_metin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.text_metin.Location = new System.Drawing.Point(68, 119);
            this.text_metin.Name = "text_metin";
            this.text_metin.Size = new System.Drawing.Size(434, 20);
            this.text_metin.TabIndex = 4;
            this.text_metin.TextChanged += new System.EventHandler(this.text_metin_TextChanged);
            // 
            // gb_alg
            // 
            this.gb_alg.Controls.Add(this.rb_caes);
            this.gb_alg.Controls.Add(this.rb_vig);
            this.gb_alg.Location = new System.Drawing.Point(68, 169);
            this.gb_alg.Name = "gb_alg";
            this.gb_alg.Size = new System.Drawing.Size(200, 100);
            this.gb_alg.TabIndex = 5;
            this.gb_alg.TabStop = false;
            this.gb_alg.Text = "Algoritmalar";
            // 
            // rb_caes
            // 
            this.rb_caes.AutoSize = true;
            this.rb_caes.Checked = true;
            this.rb_caes.Location = new System.Drawing.Point(6, 33);
            this.rb_caes.Name = "rb_caes";
            this.rb_caes.Size = new System.Drawing.Size(91, 17);
            this.rb_caes.TabIndex = 6;
            this.rb_caes.TabStop = true;
            this.rb_caes.Text = "Caesar Cipher";
            this.rb_caes.UseVisualStyleBackColor = true;
            // 
            // rb_vig
            // 
            this.rb_vig.AutoSize = true;
            this.rb_vig.Location = new System.Drawing.Point(6, 56);
            this.rb_vig.Name = "rb_vig";
            this.rb_vig.Size = new System.Drawing.Size(100, 17);
            this.rb_vig.TabIndex = 7;
            this.rb_vig.Text = "Vigenere Cipher";
            this.rb_vig.UseVisualStyleBackColor = true;
            // 
            // gb_passw
            // 
            this.gb_passw.Controls.Add(this.rb_sifre);
            this.gb_passw.Controls.Add(this.rb_desif);
            this.gb_passw.Location = new System.Drawing.Point(369, 169);
            this.gb_passw.Name = "gb_passw";
            this.gb_passw.Size = new System.Drawing.Size(200, 100);
            this.gb_passw.TabIndex = 0;
            this.gb_passw.TabStop = false;
            this.gb_passw.Text = "Şifre/Deşifreleme";
            // 
            // rb_sifre
            // 
            this.rb_sifre.AutoSize = true;
            this.rb_sifre.Checked = true;
            this.rb_sifre.Location = new System.Drawing.Point(6, 33);
            this.rb_sifre.Name = "rb_sifre";
            this.rb_sifre.Size = new System.Drawing.Size(68, 17);
            this.rb_sifre.TabIndex = 8;
            this.rb_sifre.TabStop = true;
            this.rb_sifre.Text = "Şifreleme";
            this.rb_sifre.UseVisualStyleBackColor = true;
            // 
            // rb_desif
            // 
            this.rb_desif.AutoSize = true;
            this.rb_desif.Location = new System.Drawing.Point(6, 56);
            this.rb_desif.Name = "rb_desif";
            this.rb_desif.Size = new System.Drawing.Size(80, 17);
            this.rb_desif.TabIndex = 9;
            this.rb_desif.Text = "Deşifreleme";
            this.rb_desif.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(431, 308);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 30);
            this.button1.TabIndex = 6;
            this.button1.Tag = "";
            this.button1.Text = "Şifrele/Deşifrele";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_sonuc
            // 
            this.label_sonuc.Location = new System.Drawing.Point(71, 317);
            this.label_sonuc.Name = "label_sonuc";
            this.label_sonuc.Size = new System.Drawing.Size(277, 23);
            this.label_sonuc.TabIndex = 7;
            this.label_sonuc.Text = "Şifrelenmiş ya da Deşifrelenmiş Metin:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_sonuc);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gb_passw);
            this.Controls.Add(this.gb_alg);
            this.Controls.Add(this.text_metin);
            this.Controls.Add(this.label_passw);
            this.Controls.Add(this.label_skor);
            this.Controls.Add(this.text_num);
            this.Controls.Add(this.label_no);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_alg.ResumeLayout(false);
            this.gb_alg.PerformLayout();
            this.gb_passw.ResumeLayout(false);
            this.gb_passw.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_no;
        private System.Windows.Forms.TextBox text_num;
        private System.Windows.Forms.Label label_skor;
        private System.Windows.Forms.Label label_passw;
        private System.Windows.Forms.TextBox text_metin;
        private System.Windows.Forms.GroupBox gb_alg;
        private System.Windows.Forms.RadioButton rb_caes;
        private System.Windows.Forms.RadioButton rb_vig;
        private System.Windows.Forms.GroupBox gb_passw;
        private System.Windows.Forms.RadioButton rb_sifre;
        private System.Windows.Forms.RadioButton rb_desif;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label_sonuc;
    }
}

