﻿using System;
using System.Drawing;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using testScript;

namespace second_hw
{
    public partial class Form1 : Form
    {
        private testClass test = new testClass();  //nesne yaratıldı
        private string username = "";
        private string password = "";

        public Form1()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            string userFile = "UserInfo.csv";
            if (File.Exists(userFile))  //dosya mevcut ise
            {
                using (var reader = new StreamReader(userFile))
                {
                    while (!reader.EndOfStream) //dosyayı, kullanıcıyı bulana kadar okur
                    {
                        var line = reader.ReadLine();
                        var data = line.Split(',');

                        if (data.Length == 2)
                        {
                            string username = data[0];
                            string password = data[1];

                            if (!string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password))
                            {  //boşluk değilse //// username ve password set edildi
                                this.username = username;
                                this.password = password;
                            }
                        }
                    }
                }
            }
        }

       private string GetHash(string text)   //hash function
        {
            SHA256 sha256 = SHA256Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            byte[] hash = sha256.ComputeHash(bytes);
            return BitConverter.ToString(hash).Replace("-", "").ToLower();
        } 

     private bool UserFound(string username,string password)
        {
            string userDataFile = "UserInfo.csv";
            if (File.Exists(userDataFile))
            {
                using (var reader = new StreamReader(userDataFile))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var data = line.Split(',');

                        if (data.Length == 2)
                        {
                            string user = data[0];
                            string hashpass = data[1];

                            if (user == username&& hashpass == password)  //kullanıcı adı mevcutsa ve şifre ile uyumluysa
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        private void SaveUserInfo(string username, string hashedPassword)
        {
            string csvPath = Path.Combine(Directory.GetCurrentDirectory(), "UserInfo.csv");
            using (StreamWriter sw = File.AppendText(csvPath))
            {
                sw.WriteLine($"{username},{hashedPassword}");
            }
        }

        private void button_sup_Click_1(object sender, EventArgs e)
        {
            string hashedPassw = GetHash(txtpass.Text.Trim()).ToString();
            if (txtname.Text.Length < 6||string.IsNullOrWhiteSpace(txtname.Text))
            {
                label_warn.ForeColor = Color.Red;
                label_warn.Text = "Kullanıcı adı en az 6 karakter olmalıdır ve boşluk içermemelidir.";
            }
            else if (txtpass.Text.Length < 6|| string.IsNullOrWhiteSpace(txtpass.Text))
            {
                label_warn.ForeColor = Color.Red;
                label_warn.Text = "Şifre en az 6 karakter olmalıdır ve boşluk içermemelidir.";
            }
            else if (UserFound(txtname.Text,hashedPassw))
            {
                label_warn.ForeColor = Color.Red;
                label_warn.Text = "Bu kullanıcı adı zaten mevcut, başka bir ad deneyiniz.";
            }
            else if (txtpass2.Text.Length == 0)
            {
                txtpass2.Visible = true;
                label_warn.ForeColor = Color.Blue;
                label_warn.Text = "Şifreyi tekrar giriniz, tekrar alanı boş bırakılamaz.";
            }
            else if (txtpass2.Text != txtpass.Text)
            {
                txtpass2.Visible = true;
                label_warn.ForeColor = Color.Red;
                label_warn.Text = "Şifreler eşleşmiyor.";
            }
           else{
                    label_warn.ForeColor = Color.Green;
                    label_warn.Text = "Kayıt başarılı!";
                    password = GetHash(txtpass.Text);
                    SaveUserInfo(txtname.Text, password);
                    txtname.Text = "";
                    txtpass.Text = "";
                    txtpass2.Text = "";
                    txtpass2.Visible = false;
                  /*  
                   Form2 form2 = new Form2();
                    Label label_uname = form2.Controls["label_uname"] as Label;
                    label_uname.Text = username;
                    form2.Show();
                    this.Hide(); */ //alternatif kod
           }
        }

        private void button_sin_Click_1(object sender, EventArgs e)
        {
            string password=txtpass.Text;
            string hashedPassword = GetHash(password).ToString();
            string username=txtname.Text;
            bool result = test.testUserCheck(username, hashedPassword);

            if (UserFound(txtname.Text,hashedPassword)||result) 
                {
                    label_warn.ForeColor = Color.Green;
                    label_warn.Text = "Giriş başarılı!";
                    Form2 form2 = new Form2(); 
                    /* Label label_uname = form2.Controls["label_uname"] as Label;
                    label_uname.Text = username; */  //alternatif kof
                    form2.UName = txtname.Text; 
                    form2.Show();     
                    this.Hide();
                }
                else
                {
                    label_warn.ForeColor = Color.Red;
                    label_warn.Text = "Geçersiz kullanıcı adı veya şifre.";
                }     
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            txtpass2.Visible = false;
        }

    }
}


