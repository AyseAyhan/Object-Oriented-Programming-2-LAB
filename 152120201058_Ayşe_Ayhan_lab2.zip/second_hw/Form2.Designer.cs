﻿namespace second_hw
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.textBox_test = new System.Windows.Forms.TextBox();
            this.labelsc = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.label_uname = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_test
            // 
            this.textBox_test.Location = new System.Drawing.Point(22, 89);
            this.textBox_test.Multiline = true;
            this.textBox_test.Name = "textBox_test";
            this.textBox_test.Size = new System.Drawing.Size(343, 299);
            this.textBox_test.TabIndex = 0;
            this.textBox_test.Text = resources.GetString("textBox_test.Text");
            // 
            // labelsc
            // 
            this.labelsc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelsc.Location = new System.Drawing.Point(397, 20);
            this.labelsc.Name = "labelsc";
            this.labelsc.Size = new System.Drawing.Size(209, 37);
            this.labelsc.TabIndex = 1;
            this.labelsc.Text = "SCORE:";
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnsave.Location = new System.Drawing.Point(400, 403);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 2;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // label_uname
            // 
            this.label_uname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_uname.Location = new System.Drawing.Point(19, 20);
            this.label_uname.Name = "label_uname";
            this.label_uname.Size = new System.Drawing.Size(136, 37);
            this.label_uname.TabIndex = 3;
            this.label_uname.Text = "Username";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 452);
            this.Controls.Add(this.label_uname);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.labelsc);
            this.Controls.Add(this.textBox_test);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_test;
        private System.Windows.Forms.Label labelsc;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Label label_uname;
    }
}