﻿namespace second_hw
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.button_sup = new System.Windows.Forms.Button();
            this.button_sin = new System.Windows.Forms.Button();
            this.label_warn = new System.Windows.Forms.Label();
            this.txtpass2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(32, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(32, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password:";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(140, 23);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(209, 20);
            this.txtname.TabIndex = 2;
            this.txtname.Text = "20201058";
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(140, 71);
            this.txtpass.Name = "txtpass";
            this.txtpass.PasswordChar = '*';
            this.txtpass.Size = new System.Drawing.Size(209, 20);
            this.txtpass.TabIndex = 3;
            this.txtpass.Text = "password123";
            // 
            // button_sup
            // 
            this.button_sup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_sup.Location = new System.Drawing.Point(85, 134);
            this.button_sup.Name = "button_sup";
            this.button_sup.Size = new System.Drawing.Size(75, 23);
            this.button_sup.TabIndex = 4;
            this.button_sup.Text = "Sign Up";
            this.button_sup.UseVisualStyleBackColor = true;
            this.button_sup.Click += new System.EventHandler(this.button_sup_Click_1);
            // 
            // button_sin
            // 
            this.button_sin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_sin.Location = new System.Drawing.Point(224, 134);
            this.button_sin.Name = "button_sin";
            this.button_sin.Size = new System.Drawing.Size(75, 23);
            this.button_sin.TabIndex = 5;
            this.button_sin.Text = "Sign In";
            this.button_sin.UseVisualStyleBackColor = true;
            this.button_sin.Click += new System.EventHandler(this.button_sin_Click_1);
            // 
            // label_warn
            // 
            this.label_warn.Location = new System.Drawing.Point(35, 174);
            this.label_warn.Name = "label_warn";
            this.label_warn.Size = new System.Drawing.Size(315, 23);
            this.label_warn.TabIndex = 6;
            // 
            // txtpass2
            // 
            this.txtpass2.Location = new System.Drawing.Point(140, 101);
            this.txtpass2.Name = "txtpass2";
            this.txtpass2.Size = new System.Drawing.Size(209, 20);
            this.txtpass2.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 216);
            this.Controls.Add(this.txtpass2);
            this.Controls.Add(this.label_warn);
            this.Controls.Add(this.button_sin);
            this.Controls.Add(this.button_sup);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "App-2";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Button button_sup;
        private System.Windows.Forms.Button button_sin;
        private System.Windows.Forms.Label label_warn;
        private System.Windows.Forms.TextBox txtpass2;
    }
}

