﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using testScript;

//152120201058_Ayşe_Ayhan
namespace second_hw
{
    public partial class Form2 : Form
    {
        testClass test2;
        public string UName;

        public Form2()
        {
            InitializeComponent();
        }

        private string GetHash(string text)
        {
            using (SHA256 sha256 = SHA256Managed.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                byte[] hash = sha256.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label_uname.Text = UName;
            test2 = new testClass(); //nesne oluşturuldu
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            string diary = GetHash(textBox_test.Text);

            // dosya adını tanımlama
            string fileName = $"{UName}.csv";
            // diary dosyaya eklenir   
            try
            {
                if (!File.Exists(fileName))
                {
                    StreamWriter wr=new StreamWriter(fileName);
                    wr.WriteLine(GetHash(textBox_test.Text)+(Environment.NewLine)); // File.WriteAllText(fileName, diary);
                    wr.Close();
                    int score = test2.testFuncApp2(UName, diary);
                    labelsc.Text = "Score: " + score.ToString();
                    MessageBox.Show("Diary saved successfully!");
                }
                else
                {
                  /* File.AppendAllText(fileName, diary);
                     MessageBox.Show("Diary saved successfully!");
                     int score = test2.testFuncApp2(UName, diary);
                     labelsc.Text = "Score: " + score.ToString(); */  //alternatif deneme
                   using (StreamWriter writer = new StreamWriter(fileName, true))
                    {
                        writer.Write(diary+(Environment.NewLine));
                    }

                    MessageBox.Show("Diary saved successfully!");

                    int score = test2.testFuncApp2(UName, diary);
                    labelsc.Text = "Score: " + score.ToString();   
                }        
            }
            catch (Exception)
            {
                return;       
            }
        }
       
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }   
    }
}
