﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using testScript;  // to use the dll file

namespace student_interface
{
    /*152120201058_Ayşe_Ayhan_lab1*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /* Object created from testClass in dll*/
        testClass test = new testClass();

        /*number must be 8 digits and each digits must be an integer. isValidNumber must be true*/
        /*"TryParse", inverts text to an integer.*/
        private void text_number_TextChanged(object sender, EventArgs e)
        {
            int number;
            bool isNumberValid = int.TryParse(text_number.Text, out number);

            if (text_number.Text.Length != 8 || !isNumberValid)
            {
                text_number.BackColor = Color.Red;
            }
            else
            {
                text_number.BackColor = SystemColors.Window;
            }

            EnableButton_Run();
        }

        /* Each character of name and surname must be letter. */
        private void text_name_TextChanged(object sender, EventArgs e)
        {
            bool isNameValid = text_name.Text.All(char.IsLetter);

            if (!isNameValid)
            {
                text_name.BackColor = Color.Red;
            }
            else
            {
                text_name.BackColor = SystemColors.Window;
            }

            EnableButton_Run();
        }
        private void text_lname_TextChanged(object sender, EventArgs e)
        {
            bool isLastNameValid = text_lname.Text.All(char.IsLetter);

            if (!isLastNameValid)
            {
                text_lname.BackColor = Color.Red;
            }
            else
            {
                text_lname.BackColor = SystemColors.Window;
            }

            EnableButton_Run();
        }

        private void EnableButton_Run()
        {
            button_run.Enabled = text_number.BackColor == SystemColors.Window  //if colours equal, there is no error, RUN button enabled
                && text_name.BackColor == SystemColors.Window
                && text_lname.BackColor == SystemColors.Window;
        }

        private void button_run_Click(object sender, EventArgs e)
        {
            if (text_number.BackColor != SystemColors.Window)
            {
                MessageBox.Show("Enter an 8 digit number.\nEach number must be an integer.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (text_name.BackColor != SystemColors.Window)
            {
                MessageBox.Show("Enter only letters for the name.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (text_lname.BackColor != SystemColors.Window)
            {
                MessageBox.Show("Enter only letters for the last name.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string stdName = text_name.Text;
            string stdSurname = text_lname.Text;
            string stdNumbers = text_number.Text;
            int stdNumber = Convert.ToInt32(text_number.Text);
            int numOfNums = 0;
            int numOfLetters = 0;
            string stdText = text_test.Text;

            /* This loop checks characters of text are letters or integers, it counts them*/
            for (int i = 0; i < stdText.Length; i++)
            {
                char c = stdText[i];
                if (Char.IsLetter(c))
                {
                    numOfLetters++;
                }
                else if (Char.IsDigit(c))
                {
                    numOfNums++;
                }
            }

            /* The "testFunc" function in the dll file is called to calculate the score */
            int stdScore = test.testFunc(stdNumber, stdName, stdSurname, stdText, numOfNums, numOfLetters);

            text_out.Text = "Student Number:\t\t\t" + stdNumber.ToString() + Environment.NewLine;
            text_out.Text += "Student Name:\t\t\t" + stdName + Environment.NewLine;
            text_out.Text += "Student Last Name:\t\t\t" + stdSurname + Environment.NewLine;
            text_out.Text += "Quantity of letter in test text:\t\t" + numOfLetters + Environment.NewLine;
            text_out.Text += "Quantity of number in test text:\t\t" + numOfNums + Environment.NewLine;
            text_out.Text += "Student Score:\t\t\t" + stdScore + Environment.NewLine;
        }
    }
}