﻿namespace student_interface
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_number = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_lname = new System.Windows.Forms.Label();
            this.label_test = new System.Windows.Forms.Label();
            this.label_out = new System.Windows.Forms.Label();
            this.text_number = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.text_out = new System.Windows.Forms.TextBox();
            this.text_lname = new System.Windows.Forms.TextBox();
            this.text_test = new System.Windows.Forms.TextBox();
            this.button_run = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_number
            // 
            this.label_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_number.Location = new System.Drawing.Point(23, 34);
            this.label_number.Name = "label_number";
            this.label_number.Size = new System.Drawing.Size(148, 23);
            this.label_number.TabIndex = 0;
            this.label_number.Text = "Student Number (0-9)";
            this.label_number.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_name
            // 
            this.label_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_name.Location = new System.Drawing.Point(23, 85);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(148, 23);
            this.label_name.TabIndex = 1;
            this.label_name.Text = "First Name (A-Z)";
            this.label_name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_lname
            // 
            this.label_lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_lname.Location = new System.Drawing.Point(23, 136);
            this.label_lname.Name = "label_lname";
            this.label_lname.Size = new System.Drawing.Size(148, 23);
            this.label_lname.TabIndex = 2;
            this.label_lname.Text = "Last Name (A-Z)";
            this.label_lname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_test
            // 
            this.label_test.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_test.Location = new System.Drawing.Point(23, 208);
            this.label_test.Name = "label_test";
            this.label_test.Size = new System.Drawing.Size(148, 27);
            this.label_test.TabIndex = 3;
            this.label_test.Text = "Test Text";
            this.label_test.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_out
            // 
            this.label_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_out.Location = new System.Drawing.Point(358, 34);
            this.label_out.Name = "label_out";
            this.label_out.Size = new System.Drawing.Size(123, 23);
            this.label_out.TabIndex = 4;
            this.label_out.Text = "Outputs --->";
            this.label_out.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_number
            // 
            this.text_number.Location = new System.Drawing.Point(186, 37);
            this.text_number.MaxLength = 8;
            this.text_number.Name = "text_number";
            this.text_number.Size = new System.Drawing.Size(114, 20);
            this.text_number.TabIndex = 5;
            this.text_number.Text = "20201058";
            // 
            // text_name
            // 
            this.text_name.Location = new System.Drawing.Point(186, 88);
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(114, 20);
            this.text_name.TabIndex = 6;
            this.text_name.Text = "Ayse";
            // 
            // text_out
            // 
            this.text_out.Location = new System.Drawing.Point(466, 34);
            this.text_out.Multiline = true;
            this.text_out.Name = "text_out";
            this.text_out.Size = new System.Drawing.Size(322, 224);
            this.text_out.TabIndex = 7;
            // 
            // text_lname
            // 
            this.text_lname.Location = new System.Drawing.Point(186, 139);
            this.text_lname.Name = "text_lname";
            this.text_lname.Size = new System.Drawing.Size(114, 20);
            this.text_lname.TabIndex = 8;
            this.text_lname.Text = "Ayhan";
            // 
            // text_test
            // 
            this.text_test.Location = new System.Drawing.Point(26, 238);
            this.text_test.Multiline = true;
            this.text_test.Name = "text_test";
            this.text_test.Size = new System.Drawing.Size(416, 200);
            this.text_test.TabIndex = 9;
            this.text_test.Text = "Lo1rem ip2sum do6lor si7t ame4t";
            // 
            // button_run
            // 
            this.button_run.BackColor = System.Drawing.Color.DimGray;
            this.button_run.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_run.ForeColor = System.Drawing.Color.Transparent;
            this.button_run.Location = new System.Drawing.Point(466, 313);
            this.button_run.Name = "button_run";
            this.button_run.Size = new System.Drawing.Size(322, 94);
            this.button_run.TabIndex = 10;
            this.button_run.Text = "RUN";
            this.button_run.UseVisualStyleBackColor = false;
            this.button_run.Click += new System.EventHandler(this.button_run_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_run);
            this.Controls.Add(this.text_test);
            this.Controls.Add(this.text_lname);
            this.Controls.Add(this.text_out);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.text_number);
            this.Controls.Add(this.label_out);
            this.Controls.Add(this.label_test);
            this.Controls.Add(this.label_lname);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_number);
            this.Name = "Form1";
            this.Text = "Project-1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_number;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_lname;
        private System.Windows.Forms.Label label_test;
        private System.Windows.Forms.Label label_out;
        private System.Windows.Forms.TextBox text_number;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.TextBox text_out;
        private System.Windows.Forms.TextBox text_lname;
        private System.Windows.Forms.TextBox text_test;
        private System.Windows.Forms.Button button_run;
    }
}

