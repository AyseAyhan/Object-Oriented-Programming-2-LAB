﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab7
    public partial class Form6 : Form
    {
        Form5 form5;
        private string currentId = "";
        public Form6(Form5 form5Ref)
        {
            InitializeComponent();
            form5 = form5Ref;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {         
            //add butonu için
            if (form5.flag == 1)
            {
                XDocument x = XDocument.Load(@"20201058.xml");

                if (string.IsNullOrEmpty(txt_id.Text) || string.IsNullOrEmpty(txt_utype.Text) || string.IsNullOrEmpty(txt_uname.Text) || string.IsNullOrEmpty(txt_name.Text) || string.IsNullOrEmpty(txt_mail.Text) || string.IsNullOrEmpty(txt_passw.Text))
                {
                    MessageBox.Show("Please fill in all fields.");
                }
                else
                {
                    if (x.Element("users").Elements("user").Any(a => a.Element("ID").Value.Trim() == txt_id.Text))
                    {
                        MessageBox.Show("The ID already exists in the table. Please enter a different ID.");
                    }
                    else if (x.Element("users").Elements("user").Any(a => a.Element("UserName").Value.Trim() == txt_uname.Text))
                    {
                        MessageBox.Show("The username already exists in the table. Please enter a different username.");
                    }
                    else
                    {
                        if (txt_utype.Text.ToLower() == "admin" || txt_utype.Text.ToLower() == "user")
                        {
                            x.Element("users").Add(
                            new XElement("user",
                            new XElement("ID", txt_id.Text),
                            new XElement("UserType", txt_utype.Text),
                            new XElement("UserName", txt_uname.Text),
                            new XElement("NameSurname", txt_name.Text),
                            new XElement("Mail", txt_mail.Text),
                            new XElement("Password", txt_passw.Text)
                            ));
                            x.Save(@"20201058.xml");
                            form5.ReadData();
                        }
                        else
                        {
                            MessageBox.Show("User Type must be admin or user.");
                        }
                    }
                }
            }

            //update için
            if (form5.flag == 2)
            {
                XDocument x = XDocument.Load(@"20201058.xml");
                DataGridViewRow selectedRow = form5.dataGrid.CurrentRow;
                if (string.IsNullOrEmpty(txt_id.Text) || string.IsNullOrEmpty(txt_utype.Text) || string.IsNullOrEmpty(txt_uname.Text) || string.IsNullOrEmpty(txt_name.Text) || string.IsNullOrEmpty(txt_mail.Text) || string.IsNullOrEmpty(txt_passw.Text))
                {
                    MessageBox.Show("Please fill in all fields.");
                }
                else
                {
                    if (selectedRow != null)
                    {
                        string id = selectedRow.Cells["ID"].Value.ToString().Trim();
                        XElement node = x.Element("users").Elements("user").FirstOrDefault(a => a.Element("ID").Value.Trim() == id);

                        if (node != null)
                        {
                            if (txt_utype.Text.ToLower() == "admin" || txt_utype.Text.ToLower() == "user")
                            {
                                if (txt_id.Text != id && x.Element("users").Elements("user").Any(a => a.Element("ID").Value.Trim() == txt_id.Text))
                                {
                                    MessageBox.Show("The ID already exists in the table. Please enter a different ID.");
                                }
                                else if (txt_uname.Text != node.Element("UserName").Value.Trim() && x.Element("users").Elements("user").Any(a => a.Element("UserName").Value.Trim() == txt_uname.Text))
                                {
                                    MessageBox.Show("The username already exists in the table. Please enter a different username.");
                                }
                                else
                                {
                                    node.SetElementValue("ID", txt_id.Text);
                                    node.SetElementValue("UserType", txt_utype.Text);
                                    node.SetElementValue("UserName", txt_uname.Text);
                                    node.SetElementValue("NameSurname", txt_name.Text);
                                    node.SetElementValue("Mail", txt_mail.Text);
                                    node.SetElementValue("Password", txt_passw.Text);
                                    x.Save(@"20201058.xml");
                                    int selectedRowIndex = form5.dataGrid.CurrentCell.RowIndex;
                                    form5.ReadData();
                                    form5.dataGrid.CurrentCell = form5.dataGrid.Rows[selectedRowIndex].Cells[0];
                                }
                            }
                            else
                            {
                                MessageBox.Show("UserType must be admin or user.");
                            }
                        }
                    }
                }
            }
        }             

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();           
        }

        //ID zaten alınmışsa tekrar alınamaz
        private void txt_id_TextChanged(object sender, EventArgs e)
        {         
            if (form5.flag == 2)
             {  
                 if (currentId != txt_id.Text)
                 {
                     XDocument x = XDocument.Load(@"20201058.xml");
                     DataGridViewRow selectedRow = form5.dataGrid.CurrentRow;
                     if (x.Element("users").Elements("user").Any(a => a.Element("ID").Value.Trim() == txt_id.Text && a.Element("ID").Value.Trim() != selectedRow.Cells["ID"].Value.ToString().Trim()))
                     {
                         MessageBox.Show("The ID already exists in the table. Please enter a different ID.");
                         txt_id.Text = currentId;
                     }
                     else
                     {
                         currentId = txt_id.Text;
                     }
                 }
             }
        }
    }
}

