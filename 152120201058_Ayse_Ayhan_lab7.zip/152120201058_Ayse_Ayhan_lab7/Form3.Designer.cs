﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_diff = new System.Windows.Forms.Button();
            this.btn_admin = new System.Windows.Forms.Button();
            this.btn_newgame = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btn_diff);
            this.panel1.Controls.Add(this.btn_admin);
            this.panel1.Controls.Add(this.btn_newgame);
            this.panel1.Location = new System.Drawing.Point(37, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(693, 262);
            this.panel1.TabIndex = 0;
            // 
            // btn_diff
            // 
            this.btn_diff.Location = new System.Drawing.Point(37, 86);
            this.btn_diff.Name = "btn_diff";
            this.btn_diff.Size = new System.Drawing.Size(137, 48);
            this.btn_diff.TabIndex = 1;
            this.btn_diff.Text = "Difficulties";
            this.btn_diff.UseVisualStyleBackColor = true;
            this.btn_diff.Click += new System.EventHandler(this.btn_diff_Click);
            // 
            // btn_admin
            // 
            this.btn_admin.Location = new System.Drawing.Point(276, 86);
            this.btn_admin.Name = "btn_admin";
            this.btn_admin.Size = new System.Drawing.Size(137, 48);
            this.btn_admin.TabIndex = 2;
            this.btn_admin.Text = "Admin Panel";
            this.btn_admin.UseVisualStyleBackColor = true;
            this.btn_admin.Click += new System.EventHandler(this.btn_admin_Click_1);
            // 
            // btn_newgame
            // 
            this.btn_newgame.Location = new System.Drawing.Point(515, 86);
            this.btn_newgame.Name = "btn_newgame";
            this.btn_newgame.Size = new System.Drawing.Size(137, 48);
            this.btn_newgame.TabIndex = 3;
            this.btn_newgame.Text = "New Game";
            this.btn_newgame.UseVisualStyleBackColor = true;
            this.btn_newgame.Click += new System.EventHandler(this.btn_newgame_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "settingScreen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form3_FormClosing);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_diff;
        private System.Windows.Forms.Button btn_admin;
        private System.Windows.Forms.Button btn_newgame;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}