﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_easy = new System.Windows.Forms.Button();
            this.btn_med = new System.Windows.Forms.Button();
            this.btn_hard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btn_easy);
            this.panel1.Controls.Add(this.btn_med);
            this.panel1.Controls.Add(this.btn_hard);
            this.panel1.Location = new System.Drawing.Point(1, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(785, 199);
            this.panel1.TabIndex = 0;
            // 
            // btn_easy
            // 
            this.btn_easy.Location = new System.Drawing.Point(72, 77);
            this.btn_easy.Name = "btn_easy";
            this.btn_easy.Size = new System.Drawing.Size(130, 60);
            this.btn_easy.TabIndex = 1;
            this.btn_easy.Text = "Easy";
            this.btn_easy.UseVisualStyleBackColor = true;
            this.btn_easy.Click += new System.EventHandler(this.btn_easy_Click);
            // 
            // btn_med
            // 
            this.btn_med.Location = new System.Drawing.Point(303, 77);
            this.btn_med.Name = "btn_med";
            this.btn_med.Size = new System.Drawing.Size(130, 60);
            this.btn_med.TabIndex = 2;
            this.btn_med.Text = "Medium";
            this.btn_med.UseVisualStyleBackColor = true;
            this.btn_med.Click += new System.EventHandler(this.btn_med_Click);
            // 
            // btn_hard
            // 
            this.btn_hard.Location = new System.Drawing.Point(534, 77);
            this.btn_hard.Name = "btn_hard";
            this.btn_hard.Size = new System.Drawing.Size(130, 60);
            this.btn_hard.TabIndex = 3;
            this.btn_hard.Text = "Hard";
            this.btn_hard.UseVisualStyleBackColor = true;
            this.btn_hard.Click += new System.EventHandler(this.btn_hard_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 292);
            this.Controls.Add(this.panel1);
            this.Name = "Form7";
            this.Text = "difficultyLevel";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form7_FormClosing);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_easy;
        private System.Windows.Forms.Button btn_med;
        private System.Windows.Forms.Button btn_hard;
    }
}