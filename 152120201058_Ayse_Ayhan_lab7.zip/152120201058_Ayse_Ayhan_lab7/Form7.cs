﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120201058_Ayse_Ayhan_lab4
{
    public partial class Form7 : Form
    {
        Form1 form1=new Form1();
        Form8 form8= new Form8();
        Form9 form9 = new Form9();
        public Form7()
        {
            InitializeComponent();
        }

        private void btn_easy_Click(object sender, EventArgs e)
        {
            this.Hide();
            form1.Show();
        }
        private void btn_med_Click(object sender, EventArgs e)
        {
            this.Hide();
            form8.Show();
        }
        private void btn_hard_Click(object sender, EventArgs e)
        {
            this.Hide();
            form9.Show();
        }

        private void Form7_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
