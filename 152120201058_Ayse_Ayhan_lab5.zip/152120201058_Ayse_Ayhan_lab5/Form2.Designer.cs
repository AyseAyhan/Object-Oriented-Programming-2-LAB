﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_passw = new System.Windows.Forms.TextBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_passw = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(151, 99);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(149, 20);
            this.txt_name.TabIndex = 0;
            // 
            // txt_passw
            // 
            this.txt_passw.Location = new System.Drawing.Point(148, 193);
            this.txt_passw.Name = "txt_passw";
            this.txt_passw.Size = new System.Drawing.Size(152, 20);
            this.txt_passw.TabIndex = 1;
            // 
            // lb_name
            // 
            this.lb_name.Location = new System.Drawing.Point(148, 73);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(115, 23);
            this.lb_name.TabIndex = 2;
            this.lb_name.Text = "User Name:";
            // 
            // lb_passw
            // 
            this.lb_passw.Location = new System.Drawing.Point(148, 167);
            this.lb_passw.Name = "lb_passw";
            this.lb_passw.Size = new System.Drawing.Size(100, 23);
            this.lb_passw.TabIndex = 3;
            this.lb_passw.Text = "Password:";
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(188, 241);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Log In";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 450);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.lb_passw);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.txt_passw);
            this.Controls.Add(this.txt_name);
            this.Name = "Form2";
            this.Text = "loginScreen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_passw;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_passw;
        private System.Windows.Forms.Button btn_login;
    }
}