﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120201058_Ayse_Ayhan_lab4
{
    /*152120201058_Ayşe_Ayhan_lab5*/
    public partial class Form2 : Form
    {
        Form3 form3 = new Form3();
        Form4 form4=new Form4();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        //admin ya da user değilse giriş yapılmaz
        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_name.Text.ToLower() != "user" && txt_name.Text.ToLower() != "admin")
            {
                MessageBox.Show("This username does not exist!");
            }
            else if (txt_name.Text.ToLower() == "user" && txt_passw.Text.ToLower() == "user")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                form4.Show();
                this.Hide();            
                //user paneli açılmalı

            }
            else if (txt_name.Text.ToLower() == "admin" && txt_passw.Text.ToLower() == "admin")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                form3.Show();
                this.Hide();
                
                //admin paneli açılmalı
            }
            else
            {
                MessageBox.Show("Username or password incorrect");
                txt_name.BackColor = Color.Red;
                txt_passw.BackColor = Color.Red;

            }
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
