﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab5
    public partial class Form5 : Form
    {
        public Form6 form6;
        public int flag = 0;
        
        public Form5()
        {
            InitializeComponent();
            dataGrid.ReadOnly = false;
            form6 = new Form6(this);    //form6 ya referans gönderilir        
        }

        public void ReadData() 
        {
            DataSet dset = new DataSet();
            XmlReader reader = XmlReader.Create("20201058.xml", new XmlReaderSettings());
            dset.ReadXml(reader);
            reader.Close();

            // yeni DataTable yaratılır
            DataTable dataTable = new DataTable();

            // DataTable'a sütunlar eklenir
            dataTable.Columns.Add("ID", typeof(string));
            dataTable.Columns.Add("UserType", typeof(string));
            dataTable.Columns.Add("Username", typeof(string));
            dataTable.Columns.Add("NameSurname", typeof(string));
            dataTable.Columns.Add("Mail", typeof(string));
            dataTable.Columns.Add("Password", typeof(string));

            // satırlar eklenir
            foreach (DataRow row in dset.Tables[0].Rows)
            {
                DataRow newRow = dataTable.NewRow();
                newRow["ID"] = row["ID"];
                newRow["UserType"] = row["UserType"];
                newRow["Username"] = row["Username"];
                newRow["NameSurname"] = row["NameSurname"];
                newRow["Mail"] = row["Mail"];
                newRow["Password"] = row["Password"];
                dataTable.Rows.Add(newRow);
            }
            // DataTable, dataGrid'in veri kaynağıdır
            dataGrid.DataSource = dataTable;
        }
        
        private void Form5_Load(object sender, EventArgs e) {
        dataGrid.ReadOnly = false;
        }

        //tabloyu gösterir
        private void btn_list_Click(object sender, EventArgs e)
        {
            try
            {
                ReadData();
            }
            catch { MessageBox.Show("First, enter an user please. The table is empty"); }      
        }

        //tabloya kullanıcı ekler, form6 açılır
        private void btn_add_Click(object sender, EventArgs e) 
        {
            flag = 1;  //flag değişkeni save butonunda add ve updatei ayırmak içindir
            //form6'daki textboxları sıfırlamak
            foreach (Control control in form6.Controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.Text = string.Empty;
                }
            }

            form6.ShowDialog(this);
        }

        //tabloyu günceller, seçili kullanıcının verileri form6 textlerinde gösterilir
        private void btn_update_Click(object sender, EventArgs e)
        {
            flag = 2;
           
           if (dataGrid != null && dataGrid.SelectedCells.Count != 0) //datagrid null olmamalı
            {
                // seçili satırın indexini alır
                int rowIndex = dataGrid.SelectedCells[0].RowIndex;
                // seçili satırın hücrelerini değişkenlerde tutmak için
                DataGridViewCell cell1 = dataGrid.Rows[rowIndex].Cells[0];
                DataGridViewCell cell2 = dataGrid.Rows[rowIndex].Cells[1];
                DataGridViewCell cell3 = dataGrid.Rows[rowIndex].Cells[2];
                DataGridViewCell cell4 = dataGrid.Rows[rowIndex].Cells[3];
                DataGridViewCell cell5 = dataGrid.Rows[rowIndex].Cells[4];
                DataGridViewCell cell6 = dataGrid.Rows[rowIndex].Cells[5];

                form6.txt_id.Text = cell1.Value.ToString();
                form6.txt_utype.Text = cell2.Value.ToString();
                form6.txt_uname.Text = cell3.Value.ToString();
                form6.txt_name.Text = cell4.Value.ToString();
                form6.txt_mail.Text = cell5.Value.ToString();
                form6.txt_passw.Text = cell6.Value.ToString();
                form6.ShowDialog(this);
            }
            else
            {
                MessageBox.Show("!Please make sure to select a cell and check that the table is not empty!");
            }          
        }

        //textboxa girilen ID tabloda bulunursa o kullanıcı silinir
        private void btn_delete_Click(object sender, EventArgs e)  //++
        {
            try
            {
                if (dataGrid.Rows.Count > 0 && text_rmvid.Text.Length > 0)
                {
                    XDocument x = XDocument.Load(@"20201058.xml");
                    var elem = x.Root.Elements().Where(a => a.Element("ID").Value == text_rmvid.Text).FirstOrDefault();
                    if (elem != null)
                    {
                        if (elem.Element("ID").Value != "1" && elem.Element("UserName").Value != "Aysh_theFounder")
                        {
                            elem.Remove();
                            x.Save(@"20201058.xml");
                            ReadData();
                            MessageBox.Show("Succesfully deleted.");
                            text_rmvid.Clear();
                        }
                        else
                        {
                            MessageBox.Show("The Founder Admin can not be deleted."); //kullanıcı ben isem silme işlemi yapılmaz
                        }
                    }
                    else
                    {
                        MessageBox.Show("The entered ID was not found.");
                    }
                }
                else
                {
                    MessageBox.Show("Please make sure to enter a correct ID and check that the table is not empty.");
                }
            }
            catch
            {
                MessageBox.Show("Please check that the table is not empty.");
            }
        }
        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {        
                // Uygulamayı kapatır
                Application.Exit();          
        }

    }
}
