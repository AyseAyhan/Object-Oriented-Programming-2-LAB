﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testScript;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab7
    public partial class Form1 : Form
    {
        //nesne yaratıldı
        testClass test = new testClass();
        private string stdNumber;
        private char userLetter = 'x';
        private char computerLetter = 'o';
        private short movement = 0;  //hamle sayısını tutar
        int score;

        // oyun verilerini tutmak için sözlük veri yapısı kullandım
        private Dictionary<string, char> gameState;

        public Form1()
        {
            InitializeComponent();

            // initialize game state
            gameState = new Dictionary<string, char>();
            gameState.Add("button1", '-');   //char '-' olmazsa, null olursa hata verir
            gameState.Add("button2", '-');
            gameState.Add("button3", '-');
            gameState.Add("button4", '-');
            gameState.Add("button5", '-');
            gameState.Add("button6", '-');
            gameState.Add("button7", '-');
            gameState.Add("button8", '-');
            gameState.Add("button9", '-');
        }

        private void button_Click(object sender, EventArgs e)
        {
            // oyunu resetleme butonu hep aktiftir
            btn_reset.Enabled = true;

            //numara 8 haneli olmalı ve rakamlardan oluşmalı, aksi halde oyun butonları aktif olmaz
            bool isValid = int.TryParse(txt_num.Text, out int value);
            if (txt_num.Text.Length != 8 || !isValid)
            {
                txt_num.BackColor = Color.Red;
                Button btn = sender as Button;
                btn.Enabled = false;
                MessageBox.Show("The number must be 8 digits and each digits must be integer!");
            }
            else
            {
                txt_num.BackColor = Color.White;
                stdNumber = txt_num.Text;

                Button btn = sender as Button;
                btn.Enabled = true;
                btn.BackColor = Color.White;
                btn.Text = userLetter.ToString();

                gameState[btn.Name] = userLetter;  //oyundaki durumu günceller

                if (CheckWin(userLetter))  //kazanan kullanıcıysa (x)
                {
                    btn_reset.Enabled = true;
                    MessageBox.Show($"The WINNER is {userLetter.ToString().ToUpper()}!");
                    lb_winner.Text = "Winner: " + userLetter.ToString().ToUpper();
                    btn_reset.Enabled = true;
                    EndGame();
                }
                else if (movement == 8)
                {
                    btn_reset.Enabled = true;
                    MessageBox.Show("Draw!");
                    lb_winner.Text = "Draw";
                    EndGame();
                }
                else
                {
                    movement++;
                    ComputerMove();
                    if (CheckWin(computerLetter))   //kazanan bilgisayarsa (o)
                    {
                        MessageBox.Show($"The WINNER is {computerLetter.ToString().ToUpper()}!");
                        lb_winner.Text = "Winner: " + computerLetter.ToString().ToUpper(); //kazanan, label'a da yazdırılır
                        btn_reset.Enabled = true;
                        EndGame();
                    }
                    else if (movement == 9)  //tüm kareler dolduğunda oyun berabere kalır
                    {
                        MessageBox.Show("Draw!");
                        lb_winner.Text = "Draw";
                        btn_reset.Enabled = true;
                        EndGame();
                    }
                }
                    // parametre olarak null gönderilmemesi için 
                    foreach (Button button in new Button[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 })
                    {
                        if (button.Text == null)
                        {
                            button.Text = "";
                        }
                    }
                
                // skorun hesaplanması için test nesnesi üzerinden testFuncXoX'e erişilir, numara, kazanan ve oyun durumu parametre olarak fonksiyona gönderilir
                        score = test.testFuncXoX(stdNumber, GetWinner(), gameState["button1"].ToString(),
                                             gameState["button2"].ToString(), gameState["button3"].ToString(),
                                             gameState["button4"].ToString(), gameState["button5"].ToString(),
                                             gameState["button6"].ToString(), gameState["button7"].ToString(),
                                             gameState["button8"].ToString(), gameState["button9"].ToString());              

                        // skor, ilgili labela yazdırılır                  
                              lb_score.Text = score.ToString();
                
            }
        }

        //kazananı döndüren fonksiyon, "x"-"o"-"draw"
        private string GetWinner()
        {
            if (CheckWin(userLetter))
            {
                return userLetter.ToString();
            }
            else if (CheckWin(computerLetter))
            {
                return computerLetter.ToString();
            }
            else if (movement==8||movement==9) 
            {
                return "draw";
            }
            else
            {
                return "";
            }
        }

        private void ComputerMove()
        {
            string move = GetBestMove();  // bilgisayarın en iyi hamleyi yapması için

            // butonu günceller
            Button btn = this.Controls.Find(move, true).FirstOrDefault() as Button;
            btn.Enabled = false;
            btn_reset.Enabled = true;
            btn.BackColor = Color.White;
            btn.Text = computerLetter.ToString();

            // oyun durumunu-hamlenin kimde olduğunu günceller
            gameState[move] = computerLetter;

            movement++;
        }

        private string GetBestMove()
        {         
            for (int i = 1; i <= 9; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = computerLetter;
                    if (CheckWin(computerLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }

            // rakibin kazanmasını engelleyecek buton konumuna harf koyar, doğru savunma hamleleri yapar
            for (int i = 1; i <= 9; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = userLetter;
                    if (CheckWin(userLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }
            
            if (gameState["button5"] == '-')  //merkeze harf yerleştirmek için 5 numaralı buton
            {
                return "button5";
            }

            List<string> corners = new List<string> { "button1", "button3", "button7", "button9" }; //köşeleri almak için 1-3-7-9 numaralı butonlar
            foreach (string corner in corners)
            {
                if (gameState[corner] == '-')
                {
                    return corner;
                }
            }

            List<string> sides = new List<string> { "button2", "button4", "button6", "button8" };  //yan butonları almak için 2-4-6-8 indisli butonlar
            foreach (string side in sides)
            {
                if (gameState[side] == '-')
                {
                    return side;
                }
            }

            return "";
        }

        private bool CheckWin(char letter)
        {
            //bir harf 3 kez aynı doğrultuda tekrarlandıysa kazanılır -çapraz da olabilir
            if ((gameState["button1"] == letter && gameState["button2"] == letter && gameState["button3"] == letter) ||
                (gameState["button4"] == letter && gameState["button5"] == letter && gameState["button6"] == letter) ||
                (gameState["button7"] == letter && gameState["button8"] == letter && gameState["button9"] == letter) ||
                (gameState["button1"] == letter && gameState["button4"] == letter && gameState["button7"] == letter) ||
                (gameState["button2"] == letter && gameState["button5"] == letter && gameState["button8"] == letter) ||
                (gameState["button3"] == letter && gameState["button6"] == letter && gameState["button9"] == letter) ||
                (gameState["button1"] == letter && gameState["button5"] == letter && gameState["button9"] == letter) ||
                (gameState["button3"] == letter && gameState["button5"] == letter && gameState["button7"] == letter))
            {
                return true;
            }
            return false;
        }

        private void EndGame()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    control.Enabled = false;
                    btn_reset.Enabled = true;  //oyun sonunda reset butonu kullanılabilir, diğer butonlar aktif olmadığında da reset aktif
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            // oyunu sıfırlar, butonları temizler, yeniden aktifleştirir
            gameState["button1"] = '-';
            gameState["button2"] = '-';
            gameState["button3"] = '-';
            gameState["button4"] = '-';
            gameState["button5"] = '-';
            gameState["button6"] = '-';
            gameState["button7"] = '-';
            gameState["button8"] = '-';
            gameState["button9"] = '-';

            foreach (Control control in Controls)
            {
                if (control is Button)
                {
                    control.Enabled = true;
                    control.BackColor = Color.LightGray;
                    control.Text = "";
                    btn_reset.Text = "RESET GAME";
                    btn_back.Text = "BACK";
                    btn_move.Text = "Let the computer ('o') start the game"; //oyuna başlayanın bilgisayar olması istenirse btn_move'a basılabilir //oyunu daha adil yapmak için
                }
            }

            // movement'ı ve skoru sıfırlar
            movement = 0;
            score = 0;
            lb_score.Text = "0";
            lb_winner.Text = "";

            btn_reset.Enabled = false; //yeni oyuna başlanmazsa, hiçbir butona basılmazsa, reset butonu aktif olmaz
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_reset.Enabled = true;
        }

        //ilk hamleyi bilgisayarın yapması için fazladan bir buton-tercihe bağlı
        private void btn_move_Click(object sender, EventArgs e)
        {
            ComputerMove();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            this.Close();
            form7.Show();
        }
    }
}

