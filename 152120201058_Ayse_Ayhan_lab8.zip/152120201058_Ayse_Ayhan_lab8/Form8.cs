﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058 Ayşe Ayhan lab7
    public partial class Form8 : Form
    {
        private char userLetter = 'X';
        private char computerLetter = 'O';
        private int movement = 0;

        private Dictionary<string, char> gameState;

        public Form8()
        {
            InitializeComponent();      
            gameState = new Dictionary<string, char>();
            InitializeGameState();
        }

        private void InitializeGameState()
        {
            for (int i = 1; i <= 16; i++)
            {
                string key = "button" + i;
                gameState.Add(key, '-');
            }
        }

        private void button_Click(object sender, EventArgs e)
        {       

            Button btn = (Button)sender;
            btn.ForeColor = Color.Red;

            btn_rst.Enabled = true;

            if (btn.Text == "")
            {
                gameState[btn.Name] = userLetter;
                btn.Text = userLetter.ToString();

                if (CheckWin(userLetter))
                {
                    MessageBox.Show($"The WINNER is {userLetter.ToString().ToUpper()}!");
                    lb_winner.Text = "Winner: " + userLetter.ToString().ToUpper();
                    btn_rst.Enabled = true;
                    EndGame();
                }
                else if (movement == 15)
                {
                    MessageBox.Show("Draw!");
                    lb_winner.Text = "Draw";
                    btn_rst.Enabled = true;
                    EndGame();
                }
                else
                {
                    movement++;
                    ComputerMove();
                    if (CheckWin(computerLetter))
                    {
                        MessageBox.Show($"The WINNER is {computerLetter.ToString().ToUpper()}!");
                        lb_winner.Text = "Winner: " + computerLetter.ToString().ToUpper();
                        btn_rst.Enabled = true;
                        EndGame();
                    }
                    else if (movement == 16)
                    {
                        MessageBox.Show("Draw!");
                        lb_winner.Text = "Draw";
                        btn_rst.Enabled = true;
                        EndGame();
                    }
                }
            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
          btn_rst.Enabled = true;
        }

        private void ComputerMove()
        {
            string move = GetBestMove();

            Button btn = this.Controls.Find(move, true).FirstOrDefault() as Button;
            btn.Enabled = false;
            btn_rst.Enabled = true;
            btn.BackColor = Color.White;
            btn.Text = computerLetter.ToString();

            gameState[move] = computerLetter;

            movement++;
        }

        private string GetBestMove()
        {
            for (int i = 1; i <= 16; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = computerLetter;
                    if (CheckWin(computerLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }

            for (int i = 1; i <= 16; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = userLetter;
                    if (CheckWin(userLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }

            //Merkezi almak için-9
            if (gameState["button9"] == '-')
            {
                return "button9";
            }

            //Köşeleri almak için -1-4-13-16
            List<string> corners = new List<string> { "button1", "button4", "button13", "button16" };
            foreach (string corner in corners)
            {
                if (gameState[corner] == '-')
                {
                    return corner;
                }
            }

            //Kenarları almak için -2-3-5-6-7-8-10-11-12-14-15
            List<string> sides = new List<string> { "button2", "button3", "button5", "button6", "button7", "button8", "button10", "button11", "button12", "button14", "button15" };
            foreach (string side in sides)
            {
                if (gameState[side] == '-')
                {
                    return side;
                }
            }

            return "";
        }

        private bool CheckWin(char playerLetter)
        {
            // Düşey düzlemde kazanan var mı 
            for (int i = 1; i <= 13; i += 4)
            {
                if (gameState[$"button{i}"] == playerLetter && gameState[$"button{i + 1}"] == playerLetter && gameState[$"button{i + 2}"] == playerLetter && gameState[$"button{i + 3}"] == playerLetter)
                {
                    return true;
                }
            }

            // yatay düzlende kazananı kontrol eder
            for (int i = 1; i <= 4; i++)
            {
                if (gameState[$"button{i}"] == playerLetter && gameState[$"button{i + 4}"] == playerLetter && gameState[$"button{i + 8}"] == playerLetter && gameState[$"button{i + 12}"] == playerLetter)
                {
                    return true;
                }
            }

            //kazanan için köşegenleri kontrol eder
            if (gameState["button1"] == playerLetter && gameState["button6"] == playerLetter && gameState["button11"] == playerLetter && gameState["button16"] == playerLetter)
            {
                return true;
            }

            if (gameState["button4"] == playerLetter && gameState["button7"] == playerLetter && gameState["button10"] == playerLetter && gameState["button13"] == playerLetter)
            {
                return true;
            }

            return false;
        }

        //oyunu sıfırlar
        private void ResetGame()
        {
            gameState["button1"] = '-';
            gameState["button2"] = '-';
            gameState["button3"] = '-';
            gameState["button4"] = '-';
            gameState["button5"] = '-';
            gameState["button6"] = '-';
            gameState["button7"] = '-';
            gameState["button8"] = '-';
            gameState["button9"] = '-';
            gameState["button10"] = '-';
            gameState["button11"] = '-';
            gameState["button12"] = '-';
            gameState["button13"] = '-';
            gameState["button14"] = '-';
            gameState["button15"] = '-';
            gameState["button16"] = '-';

            foreach (Control control in Controls)
            {
                if (control is Button)
                {
                    control.Enabled = true;
                    control.BackColor = Color.LightGray;
                    control.Text = "";
                    btn_rst.Text = "RESET GAME";
                    btn_back.Text = "BACK";
                }
            }

            // movement'ı ve skoru sıfırlar
            movement = 0;
            lb_winner.Text = "";

            btn_rst.Enabled = false; 
        }

        private void EndGame()
            {
                foreach (Control control in this.Controls)
                {
                    if (control is Button)
                    {
                        control.Enabled = false;
                        btn_rst.Enabled = true;  //oyun sonunda reset butonu kullanılabilir, diğer butonlar aktif olmadığında da reset aktif
                    }
                }
            }

        private void btn_rst_Click(object sender, EventArgs e)
        {
            ResetGame();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            this.Close();
            form7.Show(); //showdialog ile form kapanıyor, ikinci kez difficulty seçilmiyor//show doğru
        }
    }
}