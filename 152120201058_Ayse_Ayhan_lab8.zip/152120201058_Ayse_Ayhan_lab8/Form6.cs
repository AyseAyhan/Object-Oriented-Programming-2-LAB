﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab8
    public partial class Form6 : Form
    {
        Form5 form5;
        private string currentId = "";

        public Form6(Form5 form5Ref)
        {
            InitializeComponent();
            form5 = form5Ref;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string connectionString = form5.txt_sql.Text;

            if (form5.flag == 1)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (string.IsNullOrEmpty(txt_id.Text) || string.IsNullOrEmpty(txt_utype.Text) || string.IsNullOrEmpty(txt_uname.Text) || string.IsNullOrEmpty(txt_name.Text) || string.IsNullOrEmpty(txt_mail.Text) || string.IsNullOrEmpty(txt_passw.Text))
                    {
                        MessageBox.Show("Please fill in all fields.");
                    }
                    else if (txt_utype.Text.ToLower() != "admin" && txt_utype.Text.ToLower() != "user")
                    {
                        MessageBox.Show("User Type must be admin or user!");
                    }
                    else
                    {
                        int id;
                        if (!int.TryParse(txt_id.Text, out id))
                        {
                            MessageBox.Show("ID must be a number.");
                            return;
                        }

                        string selectQuery = $"SELECT * FROM dbo.users WHERE ID = {id} OR UserName = '{txt_uname.Text}'";
                        SqlCommand selectCommand = new SqlCommand(selectQuery, connection);
                        SqlDataReader reader = selectCommand.ExecuteReader();

                        if (reader.HasRows)
                        {
                            MessageBox.Show("The ID or username already exists in the table. Please enter different values.");
                            reader.Close(); // Close the SqlDataReader
                        }
                        else
                        {
                            reader.Close(); // Close the SqlDataReader

                            string insertQuery = $"INSERT INTO dbo.users (ID, UserType, UserName, Password, NameSurname, Mail) VALUES ({id}, '{txt_utype.Text}', '{txt_uname.Text}', '{txt_passw.Text}', '{txt_name.Text}', '{txt_mail.Text}')";
                            SqlCommand insertCommand = new SqlCommand(insertQuery, connection);
                            insertCommand.ExecuteNonQuery();

                            MessageBox.Show("User added successfully.");

                            form5.ReadData();
                        }
                    }
                }
            }

            if (form5.flag == 2)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (string.IsNullOrEmpty(txt_id.Text) || string.IsNullOrEmpty(txt_utype.Text) || string.IsNullOrEmpty(txt_uname.Text) || string.IsNullOrEmpty(txt_name.Text) || string.IsNullOrEmpty(txt_mail.Text) || string.IsNullOrEmpty(txt_passw.Text))
                    {
                        MessageBox.Show("Please fill in all fields.");
                    }
                    else if (txt_utype.Text.ToLower() != "admin" && txt_utype.Text.ToLower() != "user")
                    {
                        MessageBox.Show("User Type must be admin or user!");
                    }
                    else
                    {
                        int id;
                        if (!int.TryParse(txt_id.Text, out id))
                        {
                            MessageBox.Show("ID must be a number.");
                            return;
                        }

                        DataGridViewRow selectedRow = form5.dataGrid.CurrentRow;

                        if (selectedRow != null)
                        {
                            string selectedId = selectedRow.Cells["ID"].Value.ToString().Trim();

                            string selectQuery = $"SELECT * FROM dbo.users WHERE (ID = {id} OR UserName = '{txt_uname.Text}') AND ID != '{selectedId}'";
                            SqlCommand selectCommand = new SqlCommand(selectQuery, connection);
                            SqlDataReader reader = selectCommand.ExecuteReader();

                            if (reader.HasRows)
                            {
                                MessageBox.Show("The ID or username already exists in the table. Please enter different values.");
                                reader.Close(); // Close the SqlDataReader
                            }
                            else
                            {
                                reader.Close(); // Close the SqlDataReader

                                string updateQuery = $"UPDATE dbo.users SET ID = {id}, UserType = '{txt_utype.Text}', UserName = '{txt_uname.Text}', Password = '{txt_passw.Text}', NameSurname = '{txt_name.Text}', Mail = '{txt_mail.Text}' WHERE ID = '{selectedId}'";
                                SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
                                updateCommand.ExecuteNonQuery();

                                MessageBox.Show("User updated successfully.");

                                form5.ReadData();
                            }
                        }
                    }
                }
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ID zaten alınmışsa tekrar alınamaz
        private void txt_id_TextChanged(object sender, EventArgs e)
        {
            if (form5.flag == 2)
            {
                if (currentId != txt_id.Text)
                {
                    string connectionString = form5.txt_sql.Text;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        DataGridViewRow selectedRow = form5.dataGrid.CurrentRow;
                        string selectedId = selectedRow.Cells["ID"].Value.ToString().Trim();

                        int id;
                        if (!int.TryParse(txt_id.Text, out id))
                        {
                            MessageBox.Show("ID must be a number.");
                            txt_id.Text = currentId;
                            return;
                        }

                        string selectQuery = $"SELECT ID FROM dbo.users WHERE ID = {id} AND ID != '{selectedId}'";
                        SqlCommand selectCommand = new SqlCommand(selectQuery, connection);
                        SqlDataReader reader = selectCommand.ExecuteReader();

                        if (reader.HasRows)
                        {
                            MessageBox.Show("The ID already exists in the table. Please enter a different ID.");
                            txt_id.Text = currentId;
                        }
                        else
                        {
                            currentId = txt_id.Text;
                        }

                        reader.Close();
                    }
                }
            }
        }

    }
    }
        

