﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_winner = new System.Windows.Forms.Label();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_winner
            // 
            this.lb_winner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb_winner.ForeColor = System.Drawing.Color.Red;
            this.lb_winner.Location = new System.Drawing.Point(396, 22);
            this.lb_winner.Name = "lb_winner";
            this.lb_winner.Size = new System.Drawing.Size(121, 36);
            this.lb_winner.TabIndex = 73;
            this.lb_winner.Text = "Winner: ";
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_back.Location = new System.Drawing.Point(161, 555);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(122, 40);
            this.btn_back.TabIndex = 72;
            this.btn_back.Text = "BACK";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_reset.Location = new System.Drawing.Point(289, 555);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(122, 40);
            this.btn_reset.TabIndex = 71;
            this.btn_reset.Text = "RESET GAME";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(430, 442);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(84, 84);
            this.button25.TabIndex = 70;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.Button_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(337, 442);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(84, 84);
            this.button24.TabIndex = 69;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Button_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(244, 442);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(84, 84);
            this.button23.TabIndex = 68;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Button_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(151, 440);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(84, 84);
            this.button22.TabIndex = 67;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.Button_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(58, 440);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(84, 84);
            this.button21.TabIndex = 66;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Button_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(430, 351);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(84, 84);
            this.button20.TabIndex = 65;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.Button_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(430, 260);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(84, 84);
            this.button15.TabIndex = 64;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Button_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(430, 169);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(84, 84);
            this.button10.TabIndex = 63;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(430, 78);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(84, 84);
            this.button5.TabIndex = 62;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(337, 351);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(84, 84);
            this.button19.TabIndex = 61;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.Button_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(244, 351);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(84, 84);
            this.button18.TabIndex = 60;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.Button_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(151, 349);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(84, 84);
            this.button17.TabIndex = 59;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Button_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(58, 349);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(84, 84);
            this.button16.TabIndex = 58;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Button_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(337, 260);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(84, 84);
            this.button14.TabIndex = 57;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(244, 260);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(84, 84);
            this.button13.TabIndex = 56;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Button_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(151, 258);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(84, 84);
            this.button12.TabIndex = 55;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Button_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(58, 258);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(84, 84);
            this.button11.TabIndex = 54;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(337, 169);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(84, 84);
            this.button9.TabIndex = 53;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(244, 169);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(84, 84);
            this.button8.TabIndex = 52;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(151, 167);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(84, 84);
            this.button7.TabIndex = 51;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(58, 167);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(84, 84);
            this.button6.TabIndex = 50;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(337, 78);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 84);
            this.button4.TabIndex = 49;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(244, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 84);
            this.button3.TabIndex = 48;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(151, 76);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 84);
            this.button2.TabIndex = 47;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(58, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 84);
            this.button1.TabIndex = 46;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button_Click);
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 14);
            this.label1.TabIndex = 74;
            this.label1.Text = "20201058";
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 639);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_winner);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form9";
            this.Text = "highLevelGame";
            this.Load += new System.EventHandler(this.Form9_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_winner;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}