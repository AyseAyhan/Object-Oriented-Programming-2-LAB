﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System;
namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab7
    public partial class Form9 : Form
    {
        //nesne yaratıldı
        private char userLetter = 'X';
        private char computerLetter = 'O';
        private short movement = 0;  //hamle sayısını tutar

        // oyun verilerini tutmak için sözlük yapısı
        private Dictionary<string, char> gameState;

        public short Movement { get => movement; set => movement = value; }

        public Form9()
        {
            InitializeComponent();
            gameState = new Dictionary<string, char>();
            InitializeGameState();
        }
        private void InitializeGameState()
        {
            for (int i = 1; i <= 25; i++)
            {
                string key = "button" + i;
                gameState.Add(key, '-');
            }
        }

        //Kazanan ilan edilir
        private void Button_Click(object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            btn.ForeColor = Color.Red;

            btn_reset.Enabled = true;

            if (btn.Text == "")
            {
                gameState[btn.Name] = userLetter;
                btn.Text = userLetter.ToString();

                if (CheckWin(userLetter))
                {
                    MessageBox.Show($"The WINNER is {userLetter.ToString().ToUpper()}!");
                    lb_winner.Text = "Winner: " + userLetter.ToString().ToUpper();
                    btn_reset.Enabled = true;
                    EndGame();
                }
                else if (Movement == 24)
                {
                    MessageBox.Show("Draw!");
                    lb_winner.Text = "Draw";
                    btn_reset.Enabled = true;
                    EndGame();
                }
                else
                {
                    Movement++;
                    ComputerMove();
                    if (CheckWin(computerLetter))
                    {
                        MessageBox.Show($"The WINNER is {computerLetter.ToString().ToUpper()}!");
                        lb_winner.Text = "Winner: " + computerLetter.ToString().ToUpper();
                        btn_reset.Enabled = true;
                        EndGame();
                    }
                    else if (Movement == 25)
                    {
                        MessageBox.Show("Draw!");
                        lb_winner.Text = "Draw";
                        btn_reset.Enabled = true;
                        EndGame();
                    }
                }
            }
        }


        //kazananı döndüren fonksiyon, "x"-"o"-"draw"
        private string GetWinner()
        {
            if (CheckWin(userLetter))
            {
                return userLetter.ToString();
            }
            else if (CheckWin(computerLetter))
            {
                return computerLetter.ToString();
            }
            else if (Movement == 24 || Movement == 25)
            {
                return "draw";
            }
            else
            {
                return "";
            }
        }
        private void ComputerMove()
        {
            string move = GetBestMove();  // bilgisayarın en iyi hamleyi yapması için

            if (!string.IsNullOrEmpty(move))
            {
                // butonu günceller
                Button btn = this.Controls.Find(move, true).FirstOrDefault() as Button;
                if (btn != null)
                {
                    btn.Enabled = false;
                    btn_reset.Enabled = true;
                    btn.BackColor = Color.White;
                    btn.Text = computerLetter.ToString();

                    // oyun durumunu-hamlenin kimde olduğunu günceller
                    gameState[move] = computerLetter;

                    Movement++;
                }
            }
        }

        private string GetBestMove()
        {
            for (int i = 1; i <= 25; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = computerLetter;
                    if (CheckWin(computerLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }

            // Rakibin kazanmasını engelleyecek hamleleri yapar (doğru savunma hamleleri)
            for (int i = 1; i <= 25; i++)
            {
                string key = "button" + i;
                if (gameState[key] == '-')
                {
                    gameState[key] = userLetter;
                    if (CheckWin(userLetter))
                    {
                        gameState[key] = '-';
                        return key;
                    }
                    gameState[key] = '-';
                }
            }

            // Merkeze harf yerleştirmek için 13 numaralı butonu seçer
            if (gameState["button13"] == '-')
            {
                return "button13";
            }

            // Köşeleri almak için 1, 5, 21 ve 25 numaralı butonları seçer
            List<string> corners = new List<string> { "button1", "button5", "button21", "button25" };
            foreach (string corner in corners)
            {
                if (gameState[corner] == '-')
                {
                    return corner;
                }
            }

            // Yan butonları almak için 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22 ve 24 numaralı butonları seçer
            List<string> sides = new List<string> { "button2", "button4", "button6", "button8", "button10", "button12", "button14", "button16", "button18", "button20", "button22", "button24" };
            foreach (string side in sides)
            {
                if (gameState[side] == '-')
                {
                    return side;
                }
            }

            return "";
        }

        private bool CheckWin(char letter)
        {
            // Yatay kontrol
            if ((gameState["button1"] == letter && gameState["button2"] == letter && gameState["button3"] == letter && gameState["button4"] == letter && gameState["button5"] == letter) ||
                (gameState["button6"] == letter && gameState["button7"] == letter && gameState["button8"] == letter && gameState["button9"] == letter && gameState["button10"] == letter) ||
                (gameState["button11"] == letter && gameState["button12"] == letter && gameState["button13"] == letter && gameState["button14"] == letter && gameState["button15"] == letter) ||
                (gameState["button16"] == letter && gameState["button17"] == letter && gameState["button18"] == letter && gameState["button19"] == letter && gameState["button20"] == letter) ||
                (gameState["button21"] == letter && gameState["button22"] == letter && gameState["button23"] == letter && gameState["button24"] == letter && gameState["button25"] == letter))
            {
                return true;
            }

            // Dikey kontrol
            if ((gameState["button1"] == letter && gameState["button6"] == letter && gameState["button11"] == letter && gameState["button16"] == letter && gameState["button21"] == letter) ||
                (gameState["button2"] == letter && gameState["button7"] == letter && gameState["button12"] == letter && gameState["button17"] == letter && gameState["button22"] == letter) ||
                (gameState["button3"] == letter && gameState["button8"] == letter && gameState["button13"] == letter && gameState["button18"] == letter && gameState["button23"] == letter) ||
                (gameState["button4"] == letter && gameState["button9"] == letter && gameState["button14"] == letter && gameState["button19"] == letter && gameState["button24"] == letter) ||
                (gameState["button5"] == letter && gameState["button10"] == letter && gameState["button15"] == letter && gameState["button20"] == letter && gameState["button25"] == letter))
            {
                return true;
            }

            //Köşegenleri kontrol eder
            if ((gameState["button1"] == letter && gameState["button7"] == letter && gameState["button13"] == letter && gameState["button19"] == letter && gameState["button25"] == letter) ||
                (gameState["button3"] == letter && gameState["button7"] == letter && gameState["button11"] == letter && gameState["button15"] == letter && gameState["button19"] == letter))
            {              
                return true;
            }

            return false;
        }


        private void EndGame()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    control.Enabled = false;
                    btn_reset.Enabled = true;  //oyun sonunda reset butonu kullanılabilir, diğer butonlar aktif olmadığında da reset aktif
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            // oyunu sıfırlar, butonları temizler, yeniden aktifleştirir
            gameState["button1"] = '-';
            gameState["button2"] = '-';
            gameState["button3"] = '-';
            gameState["button4"] = '-';
            gameState["button5"] = '-';
            gameState["button6"] = '-';
            gameState["button7"] = '-';
            gameState["button8"] = '-';
            gameState["button9"] = '-';
            gameState["button10"] = '-';
            gameState["button11"] = '-';
            gameState["button12"] = '-';
            gameState["button13"] = '-';
            gameState["button14"] = '-';
            gameState["button15"] = '-';
            gameState["button16"] = '-';
            gameState["button17"] = '-';
            gameState["button18"] = '-';
            gameState["button19"] = '-';
            gameState["button20"] = '-';
            gameState["button21"] = '-';
            gameState["button22"] = '-';
            gameState["button23"] = '-';
            gameState["button24"] = '-';
            gameState["button25"] = '-';


            foreach (Control control in Controls)
            {
                if (control is Button)
                {
                    control.Enabled = true;
                    control.BackColor = Color.LightGray;
                    control.Text = "";
                    btn_reset.Text = "RESET GAME";
                    btn_back.Text = "BACK";                  
                }
            }

            // movement'ı ve skoru sıfırlar
            Movement = 0;          
            lb_winner.Text = "";

            btn_reset.Enabled = false; //yeni oyuna başlanmazsa, hiçbir butona basılmazsa, reset butonu aktif olmaz
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            btn_reset.Enabled = true;
        }

        //ilk hamleyi bilgisayarın yapması için fazladan bir buton-tercihe bağlı

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            this.Close();
            form7.Show();
        }
    }
  }
