﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab8
    public partial class Form5 : Form
    {
        public Form6 form6;
        public Form2 formiki;
        public int flag = 0;
        public string connectionString;
        public Form5()
        {
            InitializeComponent();
            dataGrid.ReadOnly = false;
            form6 = new Form6(this);    //form6 ya referans gönderilir        
        }
        public void ReadData()
        {
            if(txt_sql.Text.Length>0)
            {
                try
            {
                    connectionString = txt_sql.Text;
                    using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM dbo.users";
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    dataGrid.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
         }
        
        private void Form5_Load(object sender, EventArgs e) {
            dataGrid.ReadOnly = false;
        }

        //tabloyu gösterir
        private void btn_list_Click(object sender, EventArgs e)
        {          
                ReadData();          
        }

        public void AddFunction()
        {
            flag = 1;
            foreach (Control control in form6.Controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.Text = string.Empty;
                }
            }

            form6.Text = "registerScreen";
            form6.ShowDialog(this);

        }

        //tabloya kullanıcı ekler, form6 açılır
        private void btn_add_Click(object sender, EventArgs e) 
        {
            if (txt_sql.Text.Length > 0)
            {
                AddFunction();
            }
            else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
        }

        //tabloyu günceller, seçili kullanıcının verileri form6 textlerinde gösterilir
        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_sql.Text.Length > 0)
            {
                flag = 2;

                if (dataGrid != null && dataGrid.SelectedCells.Count != 0)
                {
                    int rowIndex = dataGrid.SelectedCells[0].RowIndex;
                    DataGridViewCell cell1 = dataGrid.Rows[rowIndex].Cells[0];
                    DataGridViewCell cell2 = dataGrid.Rows[rowIndex].Cells[1];
                    DataGridViewCell cell3 = dataGrid.Rows[rowIndex].Cells[2];
                    DataGridViewCell cell4 = dataGrid.Rows[rowIndex].Cells[3];
                    DataGridViewCell cell5 = dataGrid.Rows[rowIndex].Cells[4];
                    DataGridViewCell cell6 = dataGrid.Rows[rowIndex].Cells[5];

                    form6.txt_id.Text = cell1.Value.ToString();
                    form6.txt_utype.Text = cell2.Value.ToString();
                    form6.txt_uname.Text = cell3.Value.ToString();
                    form6.txt_passw.Text = cell4.Value.ToString();
                    form6.txt_name.Text = cell5.Value.ToString();
                    form6.txt_mail.Text = cell6.Value.ToString();
                   
                    form6.ShowDialog(this);
                }
                else
                {
                    MessageBox.Show("Please make sure to select a cell and check that the table is not empty!");
                }
            }
            else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
        }

        //textboxa girilen ID tabloda bulunursa o kullanıcı silinir
        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_sql.Text.Length > 0)
            {
                try
                {
                    if (dataGrid.Rows.Count > 0 && text_rmvid.Text.Length > 0)
                    {
                        bool idExists = false;
                        foreach (DataGridViewRow row in dataGrid.Rows)
                        {
                            if (row.Cells["ID"].Value != null && row.Cells["ID"].Value.ToString() == text_rmvid.Text)
                            {
                                idExists = true;
                                break;
                            }
                        }
                        if (idExists)
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                string query = $"DELETE FROM dbo.users WHERE ID='{text_rmvid.Text}'";
                                using (SqlCommand command = new SqlCommand(query, connection))
                                {
                                    command.ExecuteNonQuery();
                                }
                                MessageBox.Show("Successfully deleted.");
                                ReadData();
                            }
                        }
                        else
                        {
                            MessageBox.Show("ID not found.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
        }


    private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {        
                // Uygulamayı kapatır
                Application.Exit();          
        }

        //Kendi bilgisayarımda KULLANDIĞIM CONNECTİON STRİNG: Data Source= DESKTOP-GND5VRN\SQLEXPRESS;Initial Catalog=XoXGame;Persist Security Info=True;User ID=Esoguce2023;Password=Esoguce2023
        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (txt_sql.Text.Length > 0)
            {
                string connectionString;
                connectionString = txt_sql.Text; 
                SqlConnection cnn;
                cnn = new SqlConnection(connectionString);

                try
                {
                    cnn.Open();
                    MessageBox.Show("Successfully connected!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection failed: " + ex.Message);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
        }
    }
}
