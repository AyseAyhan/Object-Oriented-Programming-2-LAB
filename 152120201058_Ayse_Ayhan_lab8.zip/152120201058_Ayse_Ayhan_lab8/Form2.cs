﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;

namespace _152120201058_Ayse_Ayhan_lab4
{
    /*152120201058_Ayşe_Ayhan_lab8*/
    public partial class Form2 : Form
    {

        Form3 form3 = new Form3();
        Form4 form4=new Form4();
        Form5 form5 = new Form5();

        public Form2()
        {
            InitializeComponent();
            Init_User();
        }

        private void Init_User()
        {
            if(Properties.Settings.Default.Username!=string.Empty)
            {
                if (Properties.Settings.Default.RememberMe==true)
                {
                    txt_name.Text = Properties.Settings.Default.Username;
                    txt_passw.Text= Properties.Settings.Default.Password;
                    cb_remember.Checked = true;
                }
                else
                {
                    txt_name.Text= Properties.Settings.Default.Username;
                }
            }
        }
        private void Save_User()
        {
            if(cb_remember.Checked)
            {
                Properties.Settings.Default.Username = txt_name.Text;
                Properties.Settings.Default.Password=txt_passw.Text;
                Properties.Settings.Default.RememberMe = true;          
            }
            else
            {
                Properties.Settings.Default.Username = string.Empty;
                Properties.Settings.Default.Password = string.Empty;
                Properties.Settings.Default.RememberMe = false;
            }
            Properties.Settings.Default.Save();
        }


        //admin ya da user değilse veya kullanıcı kayıtlı değilse giriş yapılmaz
        private void btn_login_Click(object sender, EventArgs e)
        {
            
            string username = txt_name.Text.Trim();
            string password = txt_passw.Text.Trim();

            if (username.ToLower() == "user" && password.ToLower() == "user")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                Save_User();
                form4.Show();
                this.Hide();
                //user paneli açılmalı
            }
            else if (username.ToLower() == "admin" && password.ToLower() == "admin")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                Save_User();
                form3.Show();
                this.Hide();
                //admin paneli açılmalı
            }
            else
            {
                if(txt_connect.Text.Length>0)
                { 
                string connectionString = txt_connect.Text; // Veritabanı bağlantı dizesini buraya girin

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "SELECT * FROM dbo.users WHERE LOWER(UserName) = LOWER(@username)";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@username", username);
                            SqlDataReader reader = command.ExecuteReader();

                            if (reader.Read())
                            {
                                string userType = reader["UserType"].ToString().Trim().ToLower();

                                if (reader["Password"].ToString().Trim().ToLower() == password)
                                {
                                    txt_name.BackColor = SystemColors.Window;
                                    txt_passw.BackColor = SystemColors.Window;

                                    if (string.Equals(userType, "user", StringComparison.OrdinalIgnoreCase))
                                    {
                                        //kullanıcı "user" tipindeyse form4'ü aç
                                        Save_User();
                                        form4.Show();
                                    }
                                    else if (string.Equals(userType, "admin", StringComparison.OrdinalIgnoreCase))
                                    {
                                        //kullanıcı "admin" tipindeyse form3'ü aç
                                        Save_User();
                                        form3.Show();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Invalid user type");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Invalid username or password");
                                    txt_name.BackColor = Color.Red;
                                    txt_passw.BackColor = Color.Red;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Username does not exist");
                            }
                            reader.Close();
                        }                      
                    }       
                }
                else
                {
                    MessageBox.Show("Connection String can't be empty!");
                }
            }
        }

            private void rb_show_CheckedChanged(object sender, EventArgs e)
        {
            if(rb_show.Checked)
            {
                txt_passw.PasswordChar = '\0'; //metnin normal görünmesi için
            }
            else
            {
                txt_passw.PasswordChar = '*'; //şifrenin gizlenmesi için
            }
        }

        private void txt_passw_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_passw.Text))
            {
                rb_show.Checked = false; // metin kutusu boşsa show password seçimini kaldırır
            }
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            if (txt_connect.Text.Length > 0)
            {
                form5.txt_sql.Text = txt_connect.Text;  //kayıt olurken connection string sorunu çıkmaması için
                form5.AddFunction();
            }
            else
            {
                MessageBox.Show("Connection String can't be empty!");
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btn_sqlconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_connect.Text.Length > 0)
                {
                    string connectionString;
                    connectionString = txt_connect.Text;
                    SqlConnection cnn;
                    cnn = new SqlConnection(connectionString);

                    try
                    {
                        cnn.Open();
                        MessageBox.Show("Successfully connected!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Connection failed: " + ex.Message);
                    }
                    finally
                    {
                        cnn.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Connection String can't be empty!");
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Connection string is not correct!");
            }
        }
    }
}
