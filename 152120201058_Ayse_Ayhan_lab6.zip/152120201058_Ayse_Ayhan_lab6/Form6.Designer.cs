﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_id = new System.Windows.Forms.Label();
            this.lb_utype = new System.Windows.Forms.Label();
            this.lb_uname = new System.Windows.Forms.Label();
            this.lb_passw = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_mail = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_utype = new System.Windows.Forms.TextBox();
            this.txt_uname = new System.Windows.Forms.TextBox();
            this.txt_passw = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_id
            // 
            this.lb_id.AutoSize = true;
            this.lb_id.Location = new System.Drawing.Point(178, 61);
            this.lb_id.Name = "lb_id";
            this.lb_id.Size = new System.Drawing.Size(18, 13);
            this.lb_id.TabIndex = 0;
            this.lb_id.Text = "ID";
            // 
            // lb_utype
            // 
            this.lb_utype.AutoSize = true;
            this.lb_utype.Location = new System.Drawing.Point(178, 92);
            this.lb_utype.Name = "lb_utype";
            this.lb_utype.Size = new System.Drawing.Size(56, 13);
            this.lb_utype.TabIndex = 1;
            this.lb_utype.Text = "User Type";
            // 
            // lb_uname
            // 
            this.lb_uname.AutoSize = true;
            this.lb_uname.Location = new System.Drawing.Point(179, 123);
            this.lb_uname.Name = "lb_uname";
            this.lb_uname.Size = new System.Drawing.Size(55, 13);
            this.lb_uname.TabIndex = 2;
            this.lb_uname.Text = "Username";
            // 
            // lb_passw
            // 
            this.lb_passw.AutoSize = true;
            this.lb_passw.Location = new System.Drawing.Point(178, 154);
            this.lb_passw.Name = "lb_passw";
            this.lb_passw.Size = new System.Drawing.Size(53, 13);
            this.lb_passw.TabIndex = 3;
            this.lb_passw.Text = "Password";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Location = new System.Drawing.Point(178, 185);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(77, 13);
            this.lb_name.TabIndex = 4;
            this.lb_name.Text = "NameSurname";
            // 
            // lb_mail
            // 
            this.lb_mail.AutoSize = true;
            this.lb_mail.Location = new System.Drawing.Point(178, 216);
            this.lb_mail.Name = "lb_mail";
            this.lb_mail.Size = new System.Drawing.Size(26, 13);
            this.lb_mail.TabIndex = 5;
            this.lb_mail.Text = "Mail";
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(314, 54);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(100, 20);
            this.txt_id.TabIndex = 7;
            this.txt_id.TextChanged += new System.EventHandler(this.txt_id_TextChanged);
            // 
            // txt_utype
            // 
            this.txt_utype.Location = new System.Drawing.Point(314, 85);
            this.txt_utype.Name = "txt_utype";
            this.txt_utype.Size = new System.Drawing.Size(100, 20);
            this.txt_utype.TabIndex = 8;
            // 
            // txt_uname
            // 
            this.txt_uname.Location = new System.Drawing.Point(314, 116);
            this.txt_uname.Name = "txt_uname";
            this.txt_uname.Size = new System.Drawing.Size(100, 20);
            this.txt_uname.TabIndex = 9;
            // 
            // txt_passw
            // 
            this.txt_passw.Location = new System.Drawing.Point(314, 147);
            this.txt_passw.Name = "txt_passw";
            this.txt_passw.Size = new System.Drawing.Size(100, 20);
            this.txt_passw.TabIndex = 10;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(314, 178);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 11;
            // 
            // txt_mail
            // 
            this.txt_mail.Location = new System.Drawing.Point(314, 209);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(100, 20);
            this.txt_mail.TabIndex = 12;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_back.Location = new System.Drawing.Point(135, 301);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(155, 60);
            this.btn_back.TabIndex = 13;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_save.Location = new System.Drawing.Point(314, 301);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(155, 60);
            this.btn_save.TabIndex = 14;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 450);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_passw);
            this.Controls.Add(this.txt_uname);
            this.Controls.Add(this.txt_utype);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.lb_mail);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.lb_passw);
            this.Controls.Add(this.lb_uname);
            this.Controls.Add(this.lb_utype);
            this.Controls.Add(this.lb_id);
            this.Name = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_id;
        private System.Windows.Forms.Label lb_utype;
        private System.Windows.Forms.Label lb_uname;
        private System.Windows.Forms.Label lb_passw;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_mail;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_save;
        public System.Windows.Forms.TextBox txt_id;
        public System.Windows.Forms.TextBox txt_utype;
        public System.Windows.Forms.TextBox txt_uname;
        public System.Windows.Forms.TextBox txt_passw;
        public System.Windows.Forms.TextBox txt_name;
        public System.Windows.Forms.TextBox txt_mail;
    }
}