﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Windows.Forms;

namespace _152120201058_Ayse_Ayhan_lab4
{
    /*152120201058_Ayşe_Ayhan_lab5*/
    public partial class Form2 : Form
    {

        Form3 form3 = new Form3();
        Form4 form4=new Form4();
        Form5 form5 = new Form5();

        public Form2()
        {
            InitializeComponent();
            Init_User();
        }

        private void Form2_Load(object sender, EventArgs e) {}

        private void Init_User()
        {
            if(Properties.Settings.Default.Username!=string.Empty)
            {
                if (Properties.Settings.Default.RememberMe==true)
                {
                    txt_name.Text = Properties.Settings.Default.Username;
                    txt_passw.Text= Properties.Settings.Default.Password;
                    cb_remember.Checked = true;
                }
                else
                {
                    txt_name.Text= Properties.Settings.Default.Username;
                }
            }
        }
        private void Save_User()
        {
            if(cb_remember.Checked)
            {
                Properties.Settings.Default.Username = txt_name.Text;
                Properties.Settings.Default.Password=txt_passw.Text;
                Properties.Settings.Default.RememberMe = true;          
            }
            else
            {
                Properties.Settings.Default.Username = string.Empty;
                Properties.Settings.Default.Password = string.Empty;
                Properties.Settings.Default.RememberMe = false;
            }
            Properties.Settings.Default.Save();
        }


        //admin ya da user değilse veya kullanıcı kayıtlı değilse giriş yapılmaz
        private void btn_login_Click(object sender, EventArgs e)
        {

            string username = txt_name.Text.Trim();
            string password = txt_passw.Text.Trim();

            if (username.ToLower() == "user" && password.ToLower() == "user")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                Save_User();
                form4.Show();
                this.Hide();
                //user paneli açılmalı
            }
            else if (username.ToLower() == "admin" && password.ToLower() == "admin")
            {
                txt_name.BackColor = SystemColors.Window;
                txt_passw.BackColor = SystemColors.Window;
                Save_User();
                form3.Show();
                this.Hide();
                //admin paneli açılmalı
            }
            else
            {
                XDocument x = XDocument.Load(@"20201058.xml");

                var user = x.Element("users").Elements("user").FirstOrDefault(a => a.Element("UserName").Value.Trim().ToLower() == username.ToLower());

                if (user != null)
                {
                    string userType = user.Element("UserType").Value.Trim().ToLower();

                    if (user.Element("Password").Value.Trim().ToLower() == password)
                    {
                        txt_name.BackColor = SystemColors.Window;
                        txt_passw.BackColor = SystemColors.Window;

                        if (string.Equals(userType, "user", StringComparison.OrdinalIgnoreCase))
                        {
                            //kullanıcı "user" tipindeyse form4'ü aç
                            Save_User();
                            form4.Show();
                        }
                        else if (string.Equals(userType, "admin", StringComparison.OrdinalIgnoreCase))
                        {
                            //kullanıcı "admin" tipindeyse form3'ü aç
                            Save_User();
                            form3.Show();
                        }
                        else
                        {
                            MessageBox.Show("Invalid user type");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password");
                        txt_name.BackColor = Color.Red;
                        txt_passw.BackColor = Color.Red;
                    }
                }
                else
                {
                    MessageBox.Show("Username does not exist");
                }
            }
        }

     
        private void rb_show_CheckedChanged(object sender, EventArgs e)
        {
            if(rb_show.Checked)
            {
                txt_passw.PasswordChar = '\0'; //metnin normal görünmesi için
            }
            else
            {
                txt_passw.PasswordChar = '*'; //şifrenin gizlenmesi için
            }
        }

        private void txt_passw_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_passw.Text))
            {
                rb_show.Checked = false; // metin kutusu boşsa show password seçimini kaldırır
            }
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            form5.AddFunction();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
