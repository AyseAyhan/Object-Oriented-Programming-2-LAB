﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120201058_Ayse_Ayhan_lab4
{
    //152120201058_Ayşe_Ayhan_lab5
    public partial class Form3 : Form
    {
        Form1 form1 = new Form1();
        Form5 form5= new Form5();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e){}

        //admin paneli açılır
        private void btn_admin_Click_1(object sender, EventArgs e)
        {
            this.Hide();//this.Close()?
            form5.Show();
        }

        //oyun ekranı açılır
        private void btn_newgame_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            form1.Show();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
