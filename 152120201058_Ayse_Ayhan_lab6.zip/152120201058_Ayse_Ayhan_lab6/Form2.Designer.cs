﻿namespace _152120201058_Ayse_Ayhan_lab4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_passw = new System.Windows.Forms.TextBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_passw = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.rb_show = new System.Windows.Forms.RadioButton();
            this.cb_remember = new System.Windows.Forms.CheckBox();
            this.btn_register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(151, 99);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(149, 20);
            this.txt_name.TabIndex = 0;
            // 
            // txt_passw
            // 
            this.txt_passw.Location = new System.Drawing.Point(148, 172);
            this.txt_passw.Name = "txt_passw";
            this.txt_passw.PasswordChar = '*';
            this.txt_passw.Size = new System.Drawing.Size(152, 20);
            this.txt_passw.TabIndex = 1;
            this.txt_passw.TextChanged += new System.EventHandler(this.txt_passw_TextChanged);
            // 
            // lb_name
            // 
            this.lb_name.Location = new System.Drawing.Point(148, 73);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(115, 23);
            this.lb_name.TabIndex = 2;
            this.lb_name.Text = "User Name:";
            // 
            // lb_passw
            // 
            this.lb_passw.Location = new System.Drawing.Point(148, 146);
            this.lb_passw.Name = "lb_passw";
            this.lb_passw.Size = new System.Drawing.Size(100, 23);
            this.lb_passw.TabIndex = 3;
            this.lb_passw.Text = "Password:";
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(168, 329);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(95, 50);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Log In";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // rb_show
            // 
            this.rb_show.AutoSize = true;
            this.rb_show.Location = new System.Drawing.Point(151, 213);
            this.rb_show.Name = "rb_show";
            this.rb_show.Size = new System.Drawing.Size(101, 17);
            this.rb_show.TabIndex = 5;
            this.rb_show.TabStop = true;
            this.rb_show.Text = "Show Password";
            this.rb_show.UseVisualStyleBackColor = true;
            this.rb_show.CheckedChanged += new System.EventHandler(this.rb_show_CheckedChanged);
            // 
            // cb_remember
            // 
            this.cb_remember.AutoSize = true;
            this.cb_remember.Location = new System.Drawing.Point(148, 245);
            this.cb_remember.Name = "cb_remember";
            this.cb_remember.Size = new System.Drawing.Size(95, 17);
            this.cb_remember.TabIndex = 6;
            this.cb_remember.Text = "Remember Me";
            this.cb_remember.UseVisualStyleBackColor = true;   
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(148, 278);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(99, 28);
            this.btn_register.TabIndex = 7;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 450);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.cb_remember);
            this.Controls.Add(this.rb_show);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.lb_passw);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.txt_passw);
            this.Controls.Add(this.txt_name);
            this.Name = "Form2";
            this.Text = "loginScreen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_passw;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_passw;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.RadioButton rb_show;
        private System.Windows.Forms.CheckBox cb_remember;
        private System.Windows.Forms.Button btn_register;
    }
}